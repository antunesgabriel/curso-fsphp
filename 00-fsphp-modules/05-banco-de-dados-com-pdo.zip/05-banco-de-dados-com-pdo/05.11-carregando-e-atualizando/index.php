<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("05.11 - Carregando e atualizando");

require __DIR__ . "/../source/autoload.php";

use Source\Models\UserModel;

/*
 * [ save update ] Salvar o usuário ativo (Active Record)
 */

fullStackPHPClassSession("save update", __LINE__);

$model = new UserModel();

$user = $model->load(5);

if (!$user) {
    echo "<p class='trigger error'>{$model->message()}</p>";
    var_dump($model);
} else {
    echo '<p>Before Update:</p>';

    var_dump([$user]);

    echo '<p>Data entry:</p>';
    $user->last_name = 'Dias Teixeira Antunes';
    var_dump([$user]);

    echo '<p>After Update:</p>';
    $user = $user->save();

    var_dump($user);
}