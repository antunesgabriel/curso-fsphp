<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("05.04 - Consultas com query e exec");

require __DIR__ . '/../source/autoload.php';

use Source\Database\Connect;

/*
 * [ insert ] Cadastrar dados.
 * https://mariadb.com/kb/en/library/insert/
 *
 * [ PDO exec ] http://php.net/manual/pt_BR/pdo.exec.php
 * [ PDO query ]http://php.net/manual/pt_BR/pdo.query.php
 */

fullStackPHPClassSession("insert", __LINE__);

/**
 * Exec retorna 1 ou 0 para consultas,
 * para updates e deletes retorna a quantidade de linhas afetadas.
 * Em consultas ele retorna 0 pois não guarda dados como query
 * 
 * Query ele retorna mais informações como numero de linhas que veios na consulta etc..
 * O query é mais indicado para select. O exec é mais para inserção, atualização e delete,
 * para tarefas mais rapidas.
 */

try {
    $insertTest = Connect::getInstance();
    var_dump($insertTest);
    $count = $insertTest->query('SELECT * from users WHERE id > 50');

    // var_dump([
    //     'query' => $count,
    //     'rowsCount' => $count->rowCount(),
    //     'methods' => get_class_methods($count)
    // ]);

    if ($count->rowCount() === 0) {
        $result = $insertTest->exec("INSERT INTO users (first_name, last_name, email, document)
            VALUES ('Gabriel', 'Antunes', 'gabriel@antunes.com', '3244343');
            INSERT INTO users ('first_name', 'last_name', 'email', 'document')
            VALUES ('Gabriel', 'Antunes', 'gabriel@antunes.com', '3244343');
            INSERT INTO users ('first_name', 'last_name', 'email', 'document')
            VALUES ('Gabriel', 'Antunes', 'gabriel@antunes.com', '3244343');
            INSERT INTO users ('first_name', 'last_name', 'email', 'document')
            VALUES ('Gabriel', 'Antunes', 'gabriel@antunes.com', '3244343');
        ");

        var_dump($result);
    }

    $searResult = $insertTest->query('SELECT * from users WHERE id > 50');

    while ($user = $searResult->fetch()) {
        echo "<p>{$user->first_name} {$user->last_name}</p>";
    }
} catch (PDOException $exception) {
    echo "<p class='trigger error'>ERROR: {$exception->getMessage()}</p>";
}


/*
 * [ select ] Ler/Consultar dados.
 * https://mariadb.com/kb/en/library/select/
 */
fullStackPHPClassSession("select", __LINE__);


/*
 * [ update ] Atualizar dados. com exec retorna a quantidade de linhas atualizadas (que foram modificadas)
 * https://mariadb.com/kb/en/library/update/
 */
fullStackPHPClassSession("update", __LINE__);


/*
 * [ delete ] Deletar dados.
 * https://mariadb.com/kb/en/library/delete/
 */
fullStackPHPClassSession("delete", __LINE__);
try {
    $delete = Connect::getInstance();
    var_dump($delete);

    # Em delete o exec retorna a quantidade de linhas deletadas
    $result = $delete->exec('DELETE FROM users WHERE id > 50');

    var_dump($result);
} catch (PDOException $exception) {
    echo "<p class='trigger error'>ERROR: {$exception->getMessage()}</p>";
}
