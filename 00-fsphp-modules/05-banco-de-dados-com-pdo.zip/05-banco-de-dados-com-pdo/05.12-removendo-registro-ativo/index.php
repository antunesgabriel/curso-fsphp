<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("05.12 - Removendo registro ativo");

require __DIR__ . "/../source/autoload.php";

use Source\Models\UserModel;
/*
 * [ destroy ] Deleta um registro ativo
 */

fullStackPHPClassSession("destroy", __LINE__);
$model = new UserModel();

$user = $model->find('gabriel@gmail.com');

if ($user) {
    var_dump($user);

    $deletado = $user->destroy();

    if (!$deletado) {
        echo "<p class='trigger error'>{$user->message()}</p>";
    } else {
        echo "<p class='trigger accept'>{$user->message()}</p>";
    }

    var_dump($user);
} else {
    echo "<p class='trigger error'>{$model->message()}</p>";
}

/*
 * [ model destroy ] Deletar em cadeia
 */
fullStackPHPClassSession("model destroy", __LINE__);