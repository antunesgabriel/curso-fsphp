<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';

require __DIR__ . '/../source/autoload.php';

use Source\Models\AddressModel;
use Source\Models\UserModel;

fullStackPHPClassSession("AddressModel", __LINE__);

$addressModel = new AddressModel();
$userModel = new UserModel();

fullStackPHPClassSession("Create and Find, Load, All", __LINE__);

if ($userModel->find('modulo@email.com')) {
    echo '<p class="trigger warning">Usuario ja cadastrado</p>';
} else {
    $user = $userModel->bootstrap('Modulo', 'Cinco', 'modulo@email.com', 4545);
    $user->save();
    echo '<p class="trigger accept">Usuario cadastrado!</p>';

    $address = $addressModel->bootstrap($user->id, 'Rua etc', '09R');
    $feedback = $address->save();

    if ($feedback) {
        echo "<p class='trigger accept'>{$address->message()}!</p>";

        var_dump([$user, $address]);
    } else {
        echo "<p class='trigger error'>{$address->message()}</p>";
    }

    $user = null;
    $address = null;
}

fullStackPHPClassSession("Update", __LINE__);

$user = $userModel->find('modulo@email.com');

$address = $addressModel->find($user->id);

echo '<p>Before Update</p>';
var_dump($address);

$address->updated_at = date('Y-m-d H:i:s');
$address->street = 'Rua Dr. Arlindo Borges';

echo '<p>Data entry</p>';
var_dump($address);

$result = $address->save();

if ($result) {
    echo "<p class='trigger accept'>{$address->message()}</p>";
} else {
    echo "<p class='trigger error'>{$address->message()}</p>";
}

echo '<p>After Update</p>';
var_dump($address);


fullStackPHPClassSession("Delete", __LINE__);

$user = $userModel->find('modulo@email.com');
$address = $addressModel->find($user->id);

var_dump($address);

$destroy = $address->destroy();

if ($destroy) {
    echo "<p class='trigger accept'>{$address->message()}</p>";
} else {
    echo "<p class='trigger error'>{$address->message()}</p>";
}

var_dump($address);