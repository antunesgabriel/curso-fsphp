<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("05.09 - Métodos de busca e leitura");

require __DIR__ . "/../source/autoload.php";

use Source\Models\UserModel;

/*
 * [ load ] Por primary key (id)
 */

fullStackPHPClassSession("load", __LINE__);
$model = new UserModel();
$user = $model->load(1);

var_dump($user);

if ($user) {
    var_dump($user->data());
} else {
    var_dump([$model, $model->fail(), $model->message()]);
    echo "<div class='trigger error'>{$model->message()}</div>";
}

/*
 * [ find ] Por indexes da tabela (email)
 */
fullStackPHPClassSession("find", __LINE__);
$userByEmail = $model->find('robson1@email.com.br');

echo $userByEmail ?  $userByEmail->first_name : "<div class='trigger error'>{$model->message()}</div>";
/*
 * [ all ] Retorna diversos registros
 */
fullStackPHPClassSession("all", __LINE__);

$users = $model->all();

var_dump($users, $model);