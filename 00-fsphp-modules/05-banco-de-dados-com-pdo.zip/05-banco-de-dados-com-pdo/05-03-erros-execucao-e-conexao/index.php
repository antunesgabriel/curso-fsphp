<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';

fullStackPHPClassName("05.03 - Errors, conexão e execução");

/*
 * [ controle de erros ] http://php.net/manual/pt_BR/language.exceptions.php
 */
fullStackPHPClassSession("controle de erros", __LINE__);

// try catch finnaly => Exception => PDOExcepition, ErrorException ...

try {
    // throw new PDOException('Deu ruim no banco, chama o DBA!!');
    // throw new ErrorException('Teste ErrorException');
    // throw new Exception('Iiii rapaz, deu merda...');
} catch (ErrorException | PDOException $exception) {
    echo "<p class='trigger error'>{$exception->getMessage()}</p>";
} catch (Exception $exception) {
    echo "<p class='trigger error'>EXCEPITION PAI: {$exception->getMessage()}</p>";
} finally {
    echo '<p class="trigger accept">Tarefa executada</p>';
}


/*
 * [ php data object ] Uma classe PDO para manipulação de banco de dados.
 * http://php.net/manual/pt_BR/class.pdo.php
 */
fullStackPHPClassSession("php data object", __LINE__);

/**
 * PDO(
 *  dsn: 'sgbd:host=HOST_DO_BANCO;dbname=NOME_DO_BANCO;?port=PORT_DO_SERVER',
 *  user: USUARIO,
 *  password: SENHA,
 *  options: []
 * )
 */

// $pdo = null;

// try {
//     $pdo = new PDO(
//         'mysql:host=172.22.0.3;dbname=fullstackphp',
//         'antunes',
//         'antunes',
//         [
//             PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'
//         ]
//     );
// } catch (PDOException $exception) {
//     var_dump($exception);
// } finally {
//     echo '<p class="trigger accept">Conexão feita!</p>';

//     $users = $pdo->query('SELECT * FROM users LIMIT 4');

//     while ($user = $users->fetchObject()) {
//         var_dump($user);
//     }

//     var_dump([
//         'CONSULTA' => $users,
//         'METHODS' => get_class_methods($users),
//         // 'RESULT' => $users->fetchObject()
//     ]);
// }


/*
 * [ conexão com singleton ] Conextar e obter um objeto PDO garantindo instância única.
 * http://br.phptherightway.com/pages/Design-Patterns.html
 */
fullStackPHPClassSession("conexão com singleton", __LINE__);

require __DIR__ . '/../source/autoload.php';

use Source\Database\Connect;

$instance = Connect::getInstance();

$users = null;

try {
    $users = $instance->query('SELECT * FROM users LIMIT 5');

    while ($user = $users->fetch()) {
        echo "<p>{$user->first_name}</p>";
    }
} catch (PDOException $exception) {
    echo "<p class='trigger error'>{$exception->getMessage()}</p>";
} finally {
    echo '<p class="trigger accept">Processo finalizado!<p>';
}
