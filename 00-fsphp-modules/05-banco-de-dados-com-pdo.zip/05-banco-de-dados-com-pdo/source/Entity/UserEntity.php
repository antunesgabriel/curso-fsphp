<?php

namespace Source\Entity;

class UserEntity
{
    private $id;
    private $first_name;
    private $last_name;
    private $email;
    private $document;

    // public function __construct($id, $first_name, $last_name, $email, $document)
    // {
    //     var_dump([
    //         $id, $first_name, $last_name, $email, $document
    //     ]);
    // }

    public function getId(): int
    {
        return $this->id;
    }

    public function getFirstName(): string
    {
        return $this->first_name;
    }

    public function getLastName(): string
    {
        return $this->last_name;
    }

    public function getEmail(): string
    {
        return $this->email;
    }

    public function getDocument(): string
    {
        return $this->document;
    }
}