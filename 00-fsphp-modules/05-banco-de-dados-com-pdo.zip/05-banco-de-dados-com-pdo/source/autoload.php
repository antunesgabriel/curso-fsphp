<?php

spl_autoload_register(function ($namespace) {
    $rootDir = __DIR__ . '/';
    $prefix = 'Source\\';
    $length = mb_strlen($prefix);

    if (strncmp($prefix, $namespace, $length) !== 0) {
        return false;
    }

    $namespaceToPath = str_replace('\\', '/', mb_substr($namespace, $length));

    $filePath = $rootDir . $namespaceToPath . '.php';

    if (file_exists($filePath) && is_file($filePath)) {
        require $filePath;
    }
});