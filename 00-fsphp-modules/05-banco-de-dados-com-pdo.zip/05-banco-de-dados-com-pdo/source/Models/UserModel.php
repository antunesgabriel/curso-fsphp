<?php

namespace Source\Models;

use PDO;
use Source\Models\Model;

class UserModel extends Model
{
    /**
     * @var array $safe no update or create
     */
    protected static $safe = ['id', 'created_at', 'updated_at'];

    /**
     * @var string $entity database table
     */
    protected static $entity = 'users';

    public function bootstrap(string $first_name, string $last_name, string $email, string $document = null): ?UserModel
    {
        $this->first_name = $first_name;
        $this->last_name = $last_name;
        $this->email = $email;
        $this->document = $document;

        return $this;
    }

    public function load(int $id, $columns = '*'): ?UserModel
    {
        $entity = self::$entity;
        $load = $this->read("SELECT {$columns} FROM {$entity} WHERE id = :id", "id={$id}");
        if ($this->fail || !$load->rowCount()) {
            $this->message = $this->fail
                ? 'Falha ao proucurar pela ID fornecida'
                : 'Usuario não encontrado';
            return null;
        }
        return $load->fetchObject(__CLASS__);
    }

    public function find(string $email, string $columns = '*'): ?UserModel
    {
        $entity = self::$entity;

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->message = 'Email invalido';
            return null;
        }

        $find = $this->read("SELECT {$columns} FROM {$entity} WHERE email = :email", "email={$email}");
        if ($this->fail || !$find->rowCount()) {
            $this->message = $this->fail
                ? 'Falha ao proucurar pelo email fornecida'
                : 'Usuario não encontrado';
            return null;
        }
        return $find->fetchObject(__CLASS__);
    }

    public function all(int $limit = 30, int $offset = 0, string $columns = '*'): ?array
    {
        $entity = self::$entity;
        $all = $this->read(
            "SELECT {$columns} FROM {$entity} LIMIT :limite OFFSET :offset",
            "limite={$limit}&offset={$offset}"
        );

        if ($this->fail || !$all->rowCount()) {
            $this->message = $this->fail
                ? 'Falha na busca'
                : 'Nenhum usuario encontrado';
            return null;
        }
        return $all->fetchAll(PDO::FETCH_CLASS, __CLASS__);
    }

    public function save(): ?object
    {
        if (!$this->require()) {
            return null;
        }

        $entity = self::$entity;

        $userId = null;

        if (!empty($this->id)) {
            $userId = $this->id;
            $email = $this->read(
                "SELECT * FROM {$entity} WHERE email = :email AND id != :id",
                "email={$this->email}&id={$this->id}"
            );

            if ($email->rowCount()) {
                $this->message = 'Este email ja esta cadastrado';
                return null;
            }

            $data = $this->safe();

            $result = $this->update($entity, $data, 'id = :id', "id={$this->id}");

            if (!$result || $this->fail()) {
                $this->message = 'Falha ao atualizar!';
                return null;
            }

            $this->message = 'Atualizado!';
        }

        if (empty($this->id)) {
            if ($this->find($this->email)) {
                $this->message = 'Email já cadastrado';
                return null;
            }
            $userId = $this->create($entity, $this->safe());

            if ($this->fail()) {
                $this->message = 'Falha ao cadastrar usuario';
                return null;
            }

            if (!$userId) {
                $this->message = 'Falha ao cadastrar usuario';
                return null;
            }

            $this->message = 'Usuario cadastrado!';
        }

        $this->data = $this->read("SELECT * FROM {$entity} WHERE id = :id", "id={$userId}")->fetch();
        return $this;
    }

    public function destroy(): ?bool
    {
        if (empty($this->id)) {
            $this->message = 'Nenhum usuario selecionado';
            return null;
        }

        $entity = self::$entity;

        $delete = $this->delete(
            $entity,
            'id = :id AND email = :email',
            "id={$this->id}&email={$this->email}"
        );

        if (!$delete || $this->fail()) {
            $this->message = 'Falha ao deletar usuario';
            return null;
        }

        $this->data = null;
        $this->message = 'Usuario deletado com sucesso!';
        return true;
    }

    private function require(): bool
    {
        if (empty($this->first_name) || empty($this->last_name) || empty($this->email)) {
            $this->message = 'Nome, sobrenome e email são campos obrigatórios';
            return false;
        }

        if (!filter_var($this->email, FILTER_VALIDATE_EMAIL)) {
            $this->message = 'O email fornecido é invalido';
            return false;
        }

        return true;
    }
}