<?php

namespace Source\Models;

use PDOException;
use PDO;
use PDOStatement;
use StdClass;
use Source\Database\Connect;

abstract class Model
{
    /**
     * @var object|null
     */
    protected $data;
    /**
     * @var PDOExeception|null
     */
    protected $fail;
    /**
     * @var string|null
     */
    protected $message;

    public function __set($name, $value)
    {
        if (empty($this->data)) {
            $this->data = new StdClass();
        }

        $this->data->$name = $value;
    }

    public function __get($name)
    {
        if (empty($this->data)) {
            return null;
        }
        return $this->data->$name ?? null;
    }

    public function __isset($name)
    {
        return isset($this->data->$name);
    }

    public function data(): ?object
    {
        return $this->data;
    }

    public function fail(): ?PDOException
    {
        return $this->fail;
    }

    public function message(): ?string
    {
        return $this->message;
    }

    protected function read(string $select, string $params = null): ?PDOStatement
    {
        try {
            $sttm = Connect::getInstance()->prepare($select);

            if ($params) {
                parse_str($params, $params);
                $params = $this->filter((array) $params);
                foreach ($params as $key => $value) {
                    $type = (is_numeric($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
                    $sttm->bindParam(":{$key}", $value, $type);
                }
            }

            $sttm->execute();

            return $sttm;
        } catch (PDOException $exception) {
            $this->fail = $exception;
            return null;
        }
    }

    protected function create(string $entity, array $data): ?int
    {
        try {
            $columns = implode(', ', array_keys($data));
            $params = ':' . implode(', :', array_keys($data));
            $query = "INSERT INTO {$entity} ({$columns}) VALUES({$params})";

            $sttm = Connect::getInstance()->prepare($query);

            $filterData = $this->filter($data);
            $sttm->execute($filterData);

            return Connect::getInstance()->lastInsertId();
        } catch (PDOException $exception) {
            $this->fail = $exception;
            return null;
        }
    }

    protected function update(string $entity, array $data, string $terms, string $params): ?int
    {
        try {
            $keys = array_keys($data);
            $columns = [];
            foreach ($keys as $key) {
                $columns[] = "{$key} = :{$key}";
            }
            $columnsAndParams = implode(', ', $columns);
            $query = "UPDATE {$entity} SET {$columnsAndParams} WHERE {$terms}";

            parse_str($params, $params);
            $datas = $this->filter(array_merge($params, $data));

            $sttm = Connect::getInstance()->prepare($query);
            $sttm->execute($datas);

            return ($sttm->rowCount() ?? 1);
        } catch (PDOException $exception) {
            $this->fail = $exception;
            return null;
        }
    }

    protected function delete(string $entity, string $terms, string $params): ?int
    {
        try {
            $query = "DELETE FROM {$entity} WHERE {$terms}";
            parse_str($params, $params);

            $sttm = Connect::getInstance()->prepare($query);
            $sttm->execute($params);

            return ($sttm->rowCount() ?? 1);
        } catch (PDOException $exception) {
            $this->fail = $exception;
            return null;
        }
    }

    protected function safe(): array
    {
        $data = (array) $this->data;

        foreach (static::$safe as $unset) {
            unset($data[$unset]);
        }

        return $data;
    }

    private function filter(array $data): ?array
    {
        $filter = [];

        foreach ($data as $key => $value) {
            $filter[$key] = is_null($value)
                ? null
                : filter_var($value, FILTER_SANITIZE_SPECIAL_CHARS);
        }

        return $filter;
    }
}