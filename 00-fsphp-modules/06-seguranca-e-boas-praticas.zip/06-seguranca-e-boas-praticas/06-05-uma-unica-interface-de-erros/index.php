<?php
ob_start();
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("06.05 - Uma única interface de erros");

require __DIR__ . "/../source/autoload.php";

use Source\Core\Message;
use Source\Core\Session;

/*
 * [ message class ] Uma classe padrão para reportar ao usuário
 */

fullStackPHPClassSession("message class", __LINE__);

$message = new Message();

var_dump([
    $message,
    get_class_methods($message)
]);


/*
 * [ message types ] Métodos para cada tipo de mensagem
 */
fullStackPHPClassSession("message types", __LINE__);

echo $message->info('Essa é uma messagem de INFO');
echo $message->success('Essa é uma messagem de SUCCESS');
echo $message->warning('Essa é uma messagem de WARNING');
echo $message->error('Essa é uma messagem de ERROR');

/*
 * [ json message ] Mudando o padrão de retorno
 */
fullStackPHPClassSession("json message", __LINE__);
var_dump($message->json());

/*
 * [ flash message ] Uma mensagem via sessão para refresh de navegação
 */
fullStackPHPClassSession("flash message", __LINE__);
$message->flash();
$session = new Session();

var_dump([$session->all(), $_SESSION]);

echo $session->getFlash();

var_dump([$session->all(), $_SESSION]);

ob_end_flush();