<?php
require __DIR__ . "/../source/autoload.php";
$session = session();
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("06.10 - Mitigando ataques XSS e CSRF");


/*
 * [ XSS ] Cross-site Scripting
 * https://pt.wikipedia.org/wiki/Cross-site_scripting
 */
fullStackPHPClassSession("xxs", __LINE__);

$post = $_POST;

$validate = [
    'email' => FILTER_VALIDATE_EMAIL,
    'first_name' => FILTER_SANITIZE_STRING,
    'last_name' => FILTER_SANITIZE_STRING,
    'password' => FILTER_SANITIZE_STRING
];

if($post) {
    var_dump($post);
    $post = filter_input_array(INPUT_POST, $validate);
    $post = filter_var_array($post, FILTER_SANITIZE_STRIPPED);
    if (in_array(false, $post)) {
        echo message()->error('Email invalido');
        return;
    }
    echo message()->success('Recebeu um POST');
    $data = (object)$post;
    var_dump($data);
}

/*
 * [ CSRF ] Cross-Site Request Forgery
 * https://pt.wikipedia.org/wiki/Cross-site_request_forgery
 */
fullStackPHPClassSession("csrf", __LINE__);

if($_POST) {
    $datas = $_POST;
    $isValid = csrf_verify((object)$datas);
    if ($isValid) {
        $user = (object)filter_var_array($datas, [
            'email' => FILTER_VALIDATE_EMAIL,
            'first_name' => FILTER_SANITIZE_STRIPPED,
            'last_name' => FILTER_SANITIZE_STRIPPED,
            'password' => FILTER_SANITIZE_STRIPPED
        ]);

        echo message()->success('Request Valida');
        var_dump([ 
            'user' => $user,
            'post' => $_POST,
            'session' => session()->all()
        ]);
    } else {
        echo message()->error('Request invalida, Tentativa de ataque CSRF');
        var_dump([ 
            'post' => $_POST,
            'session' => session()->all()
        ]);
    }
}


/*
 * [ form ]
 */
fullStackPHPClassSession("form", __LINE__);

require __DIR__ . "/form.php";