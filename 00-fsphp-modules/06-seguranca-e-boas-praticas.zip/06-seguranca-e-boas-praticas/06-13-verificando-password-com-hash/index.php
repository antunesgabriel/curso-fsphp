<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("06.13 - Verificando password com hash");

require __DIR__ . "/../source/autoload.php";

use Source\Models\UserModel;

/*
 * [ hash ]
 */

fullStackPHPClassSession("hash", __LINE__);

$user = (new UserModel())->findById(52);

$feedback = $user->save();

if ($feedback) {
    echo message()->success('Usuarío atualizado');
} else {
    echo $user->message();
}

var_dump($user);