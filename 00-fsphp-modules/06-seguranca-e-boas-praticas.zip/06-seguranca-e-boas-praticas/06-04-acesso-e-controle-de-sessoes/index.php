<?php
require __DIR__ . '/../source/autoload.php';

use Source\Core\Session;

$session = new Session();

var_dump($session);
