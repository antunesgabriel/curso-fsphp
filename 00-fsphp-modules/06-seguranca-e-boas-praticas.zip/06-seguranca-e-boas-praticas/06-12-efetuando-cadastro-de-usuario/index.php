<?php
require __DIR__ . "/../source/autoload.php";
session();
use Source\Models\UserModel;

require __DIR__ . '/../../fullstackphp/fsphp.php';

fullStackPHPClassName("06.12 - Efetuando cadastro de usuário");


/*
 * [ register ] Uma rotina de cadastro blindada contra ataques XSS e CSRF.
 */
fullStackPHPClassSession("register", __LINE__);

$post = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRIPPED);

if ($post) {
    $data = (object)$post;

    if(csrf_verify($data)) {
        $userModel = new UserModel();
        $user = $userModel->bootstrap(
            $data->firstName,
            $data->lastName,
            $data->email,
            $data->password
        );
        $userSaved = $user->save();

        if($userSaved) {
            echo message()->success('Usuario cadastrado');
            unset($data);
        } else {
            echo $user->message();
        }
    } else {
        $error = message()->error('Falha ao enviar, preencha novamente os dados');
        unset($data);
    }
}

require_once __DIR__ . '/form.php';