<form name="post" action="./" method="post" enctype="multipart/form-data" autocomplete="off" novalidate>
    <?= $error ?? '', set_csrf(); ?>
    <input type="text" name="firstName" value="<?= ($data->firstName ?? ""); ?>" placeholder="Primeiro nome:"/>
    <input type="text" name="lastName" value="<?= ($data->lastName ?? ""); ?>" placeholder="Sobrenome:"/>
    <input type="email" name="email" value="<?= ($data->email ?? ""); ?>" placeholder="E-mail:"/>
    <input type="password" name="password" value="<?= ($data->password ?? ""); ?>" placeholder="Senha:"/>
    <button>Cadastre-se</button>
</form>