<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("06.03 - Configurações do projeto");

require __DIR__ . '/../source/autoload.php';

use Source\Models\AddressModel as Address;
use Source\Models\UserModel as User;

/*
 * [ configurações ] Um acesso global a tudo que pode ser configurado no projeto.
 */
fullStackPHPClassSession("configurações", __LINE__);


/*
 * [ refatoramento ] Iniciando o desenvolvimento de uma arquitetura de projeto.
 */
fullStackPHPClassSession("refatoramento", __LINE__);

$userModel = new User();
$addressModel = new Address();

$user = null;
$address = null;

if ($userModel->find('antunes@email.com')) {
    $user = $userModel->find('antunes@email.com');
} else {
    $user = $userModel->bootstrap(
        'Antunes',
        'Gabriel',
        'antunes@email.com',
        6565465
    );
    $user->save();
}


if ($addressModel->find($user->id)) {
    $address = $addressModel->find($user->id);
} else {
    $address = $addressModel->bootstrap(
        $user->id,
        'rua do programador',
        456
    );

    $address->save();
}

var_dump([
    'user' => $user,
    'address' => $address
]);