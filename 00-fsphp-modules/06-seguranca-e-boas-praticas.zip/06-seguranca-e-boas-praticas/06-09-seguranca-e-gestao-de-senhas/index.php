<?php
require __DIR__ . "/../source/autoload.php";

$session = session();

require __DIR__ . '/../../fullstackphp/fsphp.php';

fullStackPHPClassName("06.09 - Segurança e gestão de senhas");


/*
 * [ password hashing ] Uma API PHP para gerenciamento de senhas de modo seguro.
 */
fullStackPHPClassSession("password hashing", __LINE__);

$passHash = passwd('antunesDias');

var_dump([
    'password_hash' => $passHash,
    'pasword_get_info' => password_get_info($passHash),
    'password_verify - Teste senha correta' => passwd_verify('antunesDias', $passHash),
    'password_verify - Teste senha errada' => passwd_verify('antunesDiaz', $passHash),
    'password_needs_rehash' => passwd_rehash($passHash)
]);


/*
 * [ password saving ] Rotina de cadastro/atualização de senha
 */
fullStackPHPClassSession("password saving", __LINE__);

$user = user();

$email = 'gabriel2@gmail.com';
$myPass = 'antunes';

$user = $user->find($email);

var_dump([
    'senha_existe' => empty($user->password)
]);

if (empty($user->password)) {
    $user->password = passwd($myPass);
    $user->save();
    var_dump($user);
    message()->info($user->password);
} else {
    var_dump([
        'user' => $user,
        'senha confere' => passwd_verify($myPass, $user->password),
        'senha não confere' => passwd_verify('1324324', $user->password),
        'necessita de senha' => passwd_rehash($user->password)
    ]);

    // Colocando a mesma senha porem com outra hash
    if (passwd_rehash($user->password)) {
        $user->password = passwd($myPass);
        $user->save();
        message()->warning('Senha atualizada');
    } else {
        message()->info('Senha não precisa ser atualizada');
    }
}