<?php
ob_start();

require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("06.08 - Camada de manipulação pt3");

require __DIR__ . "/../source/autoload.php";

use Source\Core\Message;

$message = new Message();

/*
 * [ validate helpers ] Funções para sintetizar rotinas de validação
 */
fullStackPHPClassSession("validate", __LINE__);
var_dump([
    is_email('gabriel@g'),
    is_email('gabriel@gmail.com'),
    is_password('1234567'),
    is_password('12345678910101010101010101010101010101010101'),
    is_password('12345678')
]);

/*
 * [ navigation helpers ] Funções para sintetizar rotinas de navegação
 */
fullStackPHPClassSession("navigation", __LINE__);
var_dump([
    url('/path1/path3/'),
    url('/path1/path3/fdsfgdfgf'),
    url('/path1/path3/sgfdgf/sdfdf/'),
    url('path1/path3/sgfdgf/sdfdf')
]);

if(empty($_GET)) {
    redirec('/06-seguranca-e-boas-praticas/06-08-camada-de-manipulacao-pt3?f=true');
}

echo '<p class="tag">Redirecinado</p>';

/*
 * [ class triggers ] São gatilhos globais para criação de objetos
 */
fullStackPHPClassSession("triggers", __LINE__);

var_dump([
    message()->success('Funcionou!'),
    session()->set('user', user()->load(2)),
    session()->all(),
    session()->get('user')
]);

echo  message()->success('Funcionou!');

ob_end_flush();