<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("06.14 - Consulta em palavras reservadas");

require __DIR__ . "/../source/autoload.php";

use Source\Models\UserModel;

/*
 * [ query params ]
 */

fullStackPHPClassSession("query params", __LINE__);

$users = (new UserModel())->all();

var_dump($users);