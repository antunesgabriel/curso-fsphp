<?php

namespace Source\Core;

use Source\Core\Message;

class Session
{
    private const LIFETIME = CONF_SESS_LIFETIME;

    public function __construct()
    {
        if (!file_exists(CONF_SESS_PATH) && !is_dir(CONF_SESS_PATH)) {
            mkdir(CONF_SESS_PATH, 777);
        }

        if (!session_id()) {
            session_save_path(CONF_SESS_PATH);
            session_name('FSPHP');
            session_start([
                'cookie_lifetime' => self::LIFETIME
            ]);
        }
    }

    public function __set(string $key, $value)
    {
        $this->set($key, $value);
    }

    public function __get(string $key)
    {
        return $this->get($key);
    }

    public function __isset($key)
    {
        return $this->has($key);
    }

    public function set(string $key, $value): Session
    {
        $_SESSION[$key] = is_array($value) ? (object) $value : $value;
        return $this;
    }

    public function get(string $key)
    {
        return !empty($_SESSION[$key]) ? $_SESSION[$key] : null;
    }

    public function all(): ?object
    {
        return (object) $_SESSION;
    }

    public function unset(string $key): Session
    {
        unset($_SESSION[$key]);
        return $this;
    }

    public function has(string $key): bool
    {
        return isset($_SESSION[$key]);
    }

    public function regenerate()
    {
        session_regenerate_id(true);
    }

    public function destroy(): Session
    {
        session_destroy();
        return $this;
    }

    public function input_csrf()
    {
        $this->set('csrf_token', base64_encode(random_bytes(CONF_CSRF_LENGTH)));
    }

    public function getFlash(): Message
    {
        $flash = $this->get('flash');
        $this->unset('flash');
        return $flash;
    }
}