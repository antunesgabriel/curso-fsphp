<?php

namespace Source\Core;

use PDOException;
use PDO;
use PDOStatement;
use StdClass;
use Source\Core\Connect;
use Source\Core\Message;

abstract class Model
{
    /**
     * @var object|null
     */
    protected $data;
    /**
     * @var PDOExeception|null
     */
    protected $fail;
    /**
     * @var Message|null
     */
    protected $message;

    public function __construct()
    {
        $this->message = new Message();
    }

    public function __set($name, $value)
    {
        if (empty($this->data)) {
            $this->data = new StdClass();
        }

        $this->data->$name = $value;
    }

    public function __get($name)
    {
        if (empty($this->data)) {
            return null;
        }
        return $this->data->$name ?? null;
    }

    public function __isset($name)
    {
        return isset($this->data->$name);
    }

    public function data(): ?object
    {
        return $this->data;
    }

    public function fail(): ?PDOException
    {
        return $this->fail;
    }

    public function message(): ?Message
    {
        return $this->message;
    }

    protected function read(string $select, string $params = null): ?PDOStatement
    {
        try {
            $sttm = Connect::getInstance()->prepare($select);

            if ($params) {
                parse_str($params, $params);
                $params = $this->filter((array) $params);
                foreach ($params as $key => $value) {

                    if ($key === 'limit' || $key === 'init') {
                        $type = PDO::PARAM_INT;
                    } else {
                        $type = PDO::PARAM_STR;
                    }

                    $sttm->bindValue(":{$key}", $value, $type);
                }
            }


            var_dump($sttm);
            $sttm->execute();

            return $sttm;
        } catch (PDOException $exception) {
            $this->fail = $exception;
            return null;
        }
    }

    protected function create(string $entity, array $data): ?int
    {
        try {
            $columns = implode(', ', array_keys($data));
            $params = ':' . implode(', :', array_keys($data));
            $query = "INSERT INTO {$entity} ({$columns}) VALUES({$params})";

            $sttm = Connect::getInstance()->prepare($query);

            $filterData = $this->filter($data);
            $sttm->execute($filterData);

            return Connect::getInstance()->lastInsertId();
        } catch (PDOException $exception) {
            $this->fail = $exception;
            return null;
        }
    }

    protected function update(string $entity, array $data, string $terms, string $params): ?int
    {
        try {
            $keys = array_keys($data);
            $columns = [];
            foreach ($keys as $key) {
                $columns[] = "{$key} = :{$key}";
            }
            $columnsAndParams = implode(', ', $columns);
            $query = "UPDATE {$entity} SET {$columnsAndParams} WHERE {$terms}";

            parse_str($params, $params);
            $datas = $this->filter(array_merge($params, $data));

            $sttm = Connect::getInstance()->prepare($query);
            $sttm->execute($datas);

            return ($sttm->rowCount() ?? 1);
        } catch (PDOException $exception) {
            $this->fail = $exception;
            return null;
        }
    }

    protected function delete(string $entity, string $terms, string $params): ?int
    {
        try {
            $query = "DELETE FROM {$entity} WHERE {$terms}";
            parse_str($params, $params);

            $sttm = Connect::getInstance()->prepare($query);
            $sttm->execute($params);

            return ($sttm->rowCount() ?? 1);
        } catch (PDOException $exception) {
            $this->fail = $exception;
            return null;
        }
    }

    /**
     * Remove os dados do usuario que não podem  ser alterados ou inseridos manualmente
     * @return array Dados do usuario limpo
     */
    protected function safe(): array
    {
        $data = (array) $this->data;

        foreach (static::$safe as $unset) {
            unset($data[$unset]);
        }

        return $data;
    }

    private function filter(array $data): ?array
    {
        $filter = [];

        foreach ($data as $key => $value) {
            $filter[$key] = is_null($value)
                ? null
                : filter_var($value, FILTER_SANITIZE_SPECIAL_CHARS);
        }

        return $filter;
    }

    /**
     * Valida se os campos obrigtórios estão preechidos
     * @return bool
     */
    protected function require(): bool
    {
        $data = (array) $this->data;
        $datas = [];

        foreach (static::$require as $key) {
            $datas[$key] = !empty($data[$key]);
        }

        if (in_array(false, $datas)) {
            return false;
        }

        return true;
    }
}