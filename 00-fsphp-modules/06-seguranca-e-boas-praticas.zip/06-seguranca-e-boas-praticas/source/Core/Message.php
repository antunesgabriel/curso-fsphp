<?php

namespace Source\Core;

use Source\Core\Session;

class Message
{
    /**
     * @var string $text
     */
    private $text;
    /**
     * @var string $type
     */
    private $type;

    /**
     * @var string CLASSE
     */
    private const CLASSE = CONF_MSG_CLASS;

    /**
     * @var string INFO
     */
    private const INFO = CONF_MSG_INFO;

    /**
     * @var string SUCCESS
     */
    private const SUCCESS = CONF_MSG_SUCCESS;

    /**
     * @var string ERROR
     */
    private const ERROR = CONF_MSG_ERROR;

    /**
     * @var string WARNING
     */
    private const WARNING = CONF_MSG_WARNING;

    public function __toString(): string
    {
        return $this->render();
    }

    public function getType(): string
    {
        return $this->type;
    }

    public function getText(): string
    {
        return $this->text;
    }

    public function info(string $message): Message
    {
        $this->type = self::INFO;
        $this->text = $this->filter($message);
        return $this;
    }

    public function success(string $message): Message
    {
        $this->type = self::SUCCESS;
        $this->text = $this->filter($message);
        return $this;
    }

    public function warning(string $message): Message
    {
        $this->type = self::WARNING;
        $this->text = $this->filter($message);
        return $this;
    }

    public function error(string $message): Message
    {
        $this->type = self::ERROR;
        $this->text = $this->filter($message);
        return $this;
    }

    private function filter(string $message): string
    {
        return filter_var($message, FILTER_SANITIZE_SPECIAL_CHARS);
    }

    /**
     * Return HTML element for message
     * @return string
     */
    public function render(): string
    {
        $classe = self::CLASSE;
        return "<div class='{$classe} {$this->type}'>{$this->text}</div>";
    }

    public function json()
    {
        return json_encode([
            'error' => $this->getText()
        ]);
    }


    public function flash(): void
    {
        $session = new Session();

        $session->set('flash', $this);
    }
}