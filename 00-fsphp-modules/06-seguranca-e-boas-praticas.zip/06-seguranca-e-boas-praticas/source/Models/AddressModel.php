<?php

namespace Source\Models;

use PDO;
use Source\Core\Model;

class AddressModel extends Model
{
    /**
     * @var string $entity
     * */
    protected static $entity = 'address';

    /**
     * @var string $related
     */
    protected static $related = 'users';

    /**
     * @var array $safe
     */
    protected static $safe = ['id', 'created_at', 'updated_at'];

    public function bootstrap(int $userId, string $street, string $number): AddressModel
    {
        $this->user_id = $userId;
        $this->street = $street;
        $this->number = $number;

        return $this;
    }

    public function load(int $id, string $columns = '*'): ?AddressModel
    {
        $entity = self::$entity;
        $query = "SELECT {$columns} FROM {$entity} WHERE id = :id";

        $load = $this->read($query, "id={$id}");

        if ($this->fail()) {
            $this->message = 'Falha na busca';
            return null;
        }

        if ($load && !$load->rowCount()) {
            $this->message = 'Nenhum endereço encontrado';
            return null;
        }

        return $load->fetchObject(__CLASS__);
    }

    public function find(int $userId, string $columns = '*'): ?AddressModel
    {
        $entity = self::$entity;
        $query = "SELECT {$columns} FROM {$entity} WHERE user_id = :user_id";

        $find = $this->read($query, "user_id={$userId}");

        if ($this->fail()) {
            $this->message = 'Falha na busca';
            return null;
        }

        if ($find && !$find->rowCount()) {
            $this->message = 'Nenhum endereço encontrado referente a este usuario';
            return null;
        }

        return $find->fetchObject(__CLASS__);
    }

    public function all(int $limite = 30, int $offset = 0, $columns = '*'): ?array
    {
        $entity = self::$entity;
        $query = "SELECT {$columns} FROM {$entity} LIMIT :limite, :offset";

        $find = $this->read($query, "limite={$limite}&offset={$offset}");

        if ($this->fail()) {
            $this->message = 'Falha na busca';
            return null;
        }

        if ($find && !$find->rowCount()) {
            $this->message = 'Nenhum endereço encontrado';
            return null;
        }

        return $find->fetchAll(PDO::FETCH_CLASS, __CLASS__);
    }

    public function save(): ?AddressModel
    {
        if (!$this->require()) {
            return null;
        }

        $entity = self::$entity;
        $related = self::$related;
        $addressId = null;

        # For Update Address
        if (!empty($this->id)) {
            $addressId = $this->id;
            $data = $this->safe();

            $update = $this->update(
                $entity,
                $data,
                'user_id = :user_id AND id = :id',
                "user_id={$this->user_id}&id={$this->id}"
            );

            if ($this->fail()) {
                $this->message = 'Falha ao atualizar';
                return null;
            }

            $this->message = "Foram atualizados {$update} registros";
        }

        if (empty($this->id)) {
            $userExist = $this->read("SELECT * FROM {$related} WHERE id = :id", "id={$this->user_id}");
            if (!$userExist) {
                $this->message = 'Falha ao cadastrar endereço';
                return null;
            }

            if (!$userExist->rowCount()) {
                $this->message = 'Usuario da ID  informado não existe';
                return null;
            }

            $userHaveAddress = $this->read("SELECT * FROM {$entity} WHERE user_id = :user_id", "user_id={$this->user_id}");

            if (!$userHaveAddress) {
                $this->message = 'Falha ao cadastrar endereço';
                return null;
            }

            if ($userHaveAddress->rowCount()) {
                $this->message = 'Esse usuario ja possui um endereço cadastrado';
                return null;
            }

            $addressId = $this->create($entity, $this->safe());

            echo $addressId;

            if (!$addressId) {
                $this->message = 'Falha ao cadastrar endereço';
                return null;
            }

            $this->message = 'Endereço cadastrado';
        }

        $data = $this->read("SELECT * FROM {$entity} WHERE id = :id", "id={$addressId}");

        $this->data = $data->fetch();

        return $this;
    }

    public function destroy(): ?int
    {
        if (empty($this->id)) {
            $this->message = 'Nenhum endereço registrado selecionado';
            return null;
        }

        $entity = self::$entity;

        $rows = $this->delete(
            $entity,
            'id = :id AND user_id = :user_id',
            "id={$this->id}&user_id={$this->user_id}"
        );

        if ($this->fail()) {
            $this->message = 'Falha ao excluir endereço';
            return null;
        }

        $this->message = "Foram deletados {$rows} registros";
        $this->data = null;
        return $rows;
    }

    public function require()
    {
        if (empty($this->street) || empty($this->number) || empty($this->user_id)) {
            $this->message = 'Rua, numero e id do usuario são obrigatórios';
            return false;
        }

        return true;
    }
}