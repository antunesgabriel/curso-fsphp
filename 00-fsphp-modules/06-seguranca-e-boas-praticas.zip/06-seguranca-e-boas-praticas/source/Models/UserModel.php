<?php

namespace Source\Models;

use PDO;
use Source\Core\Model;

class UserModel extends Model
{
    /**
     * @var array $safe no update or create
     */
    protected static $safe = ['id', 'created_at', 'updated_at'];

    /**
     * @var string $entity database table
     */
    protected static $entity = 'users';

    protected static $require = ['first_name', 'last_name', 'email', 'password'];

    public function bootstrap(
        string $first_name,
        string $last_name,
        string $email,
        string $password,
        string $document = null
    ): ?UserModel {
        $this->first_name = $first_name;
        $this->last_name = $last_name;
        $this->email = $email;
        $this->password = $password;
        $this->document = $document;

        return $this;
    }


    /**
     * Busca por usuario personalizado
     * @param string $terms Termos da consulta
     * @param string $params Parametros com valores dos termos
     * @param string $columns colunas a serem retornadas
     * @return null|UserModel
     */
    public function find(string $terms, string $params, string $columns = '*'): ?UserModel
    {
        $entity = self::$entity;

        $result = $this->read("SELECT {$columns} FROM {$entity} WHERE {$terms}", $params);

        $haveFail = $this->fail();

        if ($haveFail || !$result->rowCount()) {
            $error = $haveFail ? $haveFail->getMessage() : 'Nenhum usuario encontrado';
            $this->message->warning($error);
            return null;
        }

        return $result->fetchObject(__CLASS__);
    }

    /**
     * Busca usuario pela id
     * @param int $id
     * @param string $columns colunas a serem retornadas
     * @return null|UserModel
     */
    public function findById(int $id, $columns = '*'): ?UserModel
    {
        if (!filter_var($id, FILTER_VALIDATE_INT)) {
            $this->message->warning('ID invalida');
            return null;
        }

        $user = $this->find('id = :id', "id={$id}", $columns);

        if (!$user) {
            $hasFail = $this->fail();
            $error = $hasFail ? 'Falha na execução da busca' : 'Nenhum usuario encontrado';
            $this->message->warning($error);
            return null;
        }

        return $user;
    }


    /**
     * Busca usuario pr email
     * @param string $email
     * @param string $columns colunas a serem retornadas
     * @return null|UserModel
     */
    public function findByEmail(string $email, string $columns = '*'): ?UserModel
    {

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->message->warning('Email invalido');
            return null;
        }


        $user = $this->find('email = :email', "email={$email}", $columns);

        if (!$user) {
            $hasFail = $this->fail();
            $error = $hasFail ? 'Falha na execução da busca' : 'Nenhum usuario com este email';
            $this->message->warning($error);
            return null;
        }

        return $user;
    }

    public function all(int $limit = 30, int $init = 0, string $columns = '*'): ?array
    {
        $entity = self::$entity;
        $all = $this->read(
            "SELECT {$columns} FROM {$entity} LIMIT :init, :limit",
            "limit={$limit}&init={$init}"
        );

        if ($this->fail || !$all->rowCount()) {
            $error = $this->fail() ? $this->fail()->getMessage() : 'Nenhum usuario encontrado';
            $this->message->warning($error);
            return null;
        }
        return $all->fetchAll(PDO::FETCH_CLASS, __CLASS__);
    }

    public function save(): ?UserModel
    {
        if (!$this->require()) {
            $this->message()->warning('Nome, sobrenome, email e password devem ser preenchidos');
            return null;
        }

        if (!is_email($this->email)) {
            $this->message()->error('Email invalido');
            return null;
        }

        if (!is_password($this->password)) {
            $min = CONF_MIN_PASS_LENGTH;
            $max = CONF_MAX_PASS_LENGTH;
            $this->message()->error(
                "Senha invalida, a senha deve ter entre {$min} e {$max} caracteres"
            );
            return null;
        }

        $this->password = passwd($this->password);

        $entity = self::$entity;

        $userId = null;

        if (!empty($this->id)) {
            $userId = $this->id;

            $emailExist = $this->find('email = :email AND id != :id', "email={$this->email}&id={$this->id}");

            if ($emailExist) {
                $this->message->warning('Este email ja esta cadastrado');
                return null;
            }

            $data = $this->safe();

            $rowsUpdated = $this->update($entity, $data, 'id = :id', "id={$this->id}");

            $hasFail = $this->fail();

            if (!$rowsUpdated || $hasFail) {
                $error = 'Falha no processo de atualização';
                $this->message->warning($error);
                return null;
            }
        }


        if (empty($this->id)) {
            $emailExist = $this->findByEmail($this->email);

            if ($this->findByEmail($this->email)) {
                $this->message->warning('Email já cadastrado');
                return null;
            }


            $userId = $this->create($entity, $this->safe());

            $hasFail = $this->fail();

            if (!$userId || $hasFail) {
                $this->message->warning($hasFail->getMessage());
                return null;
            }
        }

        $this->data = $this->read("SELECT * FROM {$entity} WHERE id = :id", "id={$userId}")->fetch();
        return $this;
    }

    public function destroy(): ?bool
    {
        if (empty($this->id)) {
            $this->message = 'Nenhum usuario selecionado';
            return null;
        }

        $entity = self::$entity;

        $delete = $this->delete(
            $entity,
            'id = :id AND email = :email',
            "id={$this->id}&email={$this->email}"
        );

        if (!$delete || $this->fail()) {
            $this->message = 'Falha ao deletar usuario';
            return null;
        }

        $this->data = null;
        $this->message = 'Usuario deletado com sucesso!';
        return true;
    }
}