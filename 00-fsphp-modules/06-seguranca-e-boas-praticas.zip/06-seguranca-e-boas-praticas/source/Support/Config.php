<?php

# DB
define('CONF_DB_HOST', '172.22.0.2');
define('CONF_DB_USERNAME', 'antunes');
define('CONF_DB_PASSWORD', 'antunes');
define('CONF_DB_NAME', 'fullstackphp');
define('CONF_DB_DNS', 'mysql');

# Date
define('CONF_DATE_BR', 'd/m/Y H:i:s');
define('CONF_DATE_DB', 'Y-m-d H:i:s');

# URL
define('CONF_URL_BASE', 'https://localhost/fsphp');
define('CONF_URL_ADMIN', CONF_URL_BASE . '/admin');
define('CONF_URL_ERROR', CONF_URL_BASE . '/404');

# Session
define('CONF_SESS_PATH', __DIR__ . '/../../storage');
define('CONF_SESS_LIFETIME', 60 * 60 * 4);

# Message
define('CONF_MSG_CLASS', 'trigger');
define('CONF_MSG_INFO', 'info');
define('CONF_MSG_SUCCESS', 'success');
define('CONF_MSG_ERROR', 'error');
define('CONF_MSG_WARNING', 'warning');

# Password
define('CONF_MIN_PASS_LENGTH', 8);
define('CONF_MAX_PASS_LENGTH', 40);
define('CONF_PASS_ALGO', PASSWORD_DEFAULT);
define('CONF_PASS_COST', 10);

# CSRF
define('CONF_CSRF_LENGTH', 20);
define('CONF_CSRF_NAME', 'csrf_token');