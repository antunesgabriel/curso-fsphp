<?php

use Source\Core\Connect;
use Source\Core\Message;
use Source\Core\Session;
use Source\Models\UserModel as User;

/**
 * #######################
 * ##### Validação #######
 * #######################
 */

/**
 * Valida um email
 * @param string $email
 * @return bool
 */
function is_email(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Valida o tamanho da senha
 * @param string $password
 * @return bool
 */
function is_password(string $password): bool
{
    if (password_get_info($password)['algo']) {
        return true;
    }
    $passLength = mb_strlen($password);
    return ($passLength >= CONF_MIN_PASS_LENGTH && $passLength <= CONF_MAX_PASS_LENGTH);
}


/**
 * #######################
 * ######  STRINGS #######
 * #######################
 */

/**
 * Converte uma strin em slug
 * @param string $string String a ser convertida
 * @return string
 */
function str_slug(string $string): string
{
    $loweCase = filter_var(mb_strtolower($string), FILTER_SANITIZE_STRIPPED);
    $formats = 'ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜüÝÞßàáâãäåæçèéêëìíîïðñòóôõöøùúûýýþÿRr"!@#$%&*()_-+={[}]/?;:.,\\\'<>°ºª';
    $replace = 'aaaaaaaceeeeiiiidnoooooouuuuuybsaaaaaaaceeeeiiiidnoooooouuuyybyRr                                 ';
    $clear = trim(strtr(utf8_decode($loweCase), utf8_decode($formats), $replace));
    $slug = preg_replace('/\s+/', '-', $clear);
    return $slug;
}


/**
 * Converte um slug em Camel Case
 * @param string $string String a ser convertida
 * @return string
 */
function str_study_case(string $string): string
{
    $string = filter_var($string, FILTER_SANITIZE_STRIPPED);
    $study = preg_replace('/-+/', ' ', $string);
    $study = mb_convert_case($study, MB_CASE_TITLE);
    $study = str_replace(' ', '', $study);
    return $study;
}

/**
 * Converte string para camel case
 * @param string $string
 * @return string
 */
function str_camel_case(string $string): string
{
    return lcfirst(str_study_case($string));
}


/**
 * Converte string em titulo
 * @param string $string
 * @return string
 */
function str_title(string $string): string
{
    $string = filter_var($string, FILTER_SANITIZE_SPECIAL_CHARS);
    $string = mb_convert_case($string, MB_CASE_TITLE);
    return $string;
}

/**
 * Retorna uma string com limite de palavras
 * @param string $string
 * @return string
 */
function str_limit_works(string $string, int $limit, string $tail = '...'): string
{
    $filter = filter_var(trim($string), FILTER_SANITIZE_SPECIAL_CHARS);
    $arrayWorks = explode(' ', $filter);

    if (count($arrayWorks) <= $limit) {
        $limitedWorks = implode(' ', $arrayWorks);
        return "{$limitedWorks}{$tail}";
    }

    $limitedWorks = implode(' ', array_slice($arrayWorks, 0, $limit));

    return "{$limitedWorks}{$tail}";
}

function str_limit_char(string $string, int $limit): string
{
    $trim = trim($string);
    $filter = filter_var($trim, FILTER_SANITIZE_SPECIAL_CHARS);

    if (mb_strlen($filter) <= $limit) {
        return $filter;
    }
    $limited = mb_substr($filter, 0, $limit);
    $lastSpace = mb_strrpos($limited, ' ');
    $limited = mb_substr($filter, 0, $lastSpace);
    return trim($limited);
}

/**
 * Transforma um path em url
 * @param string $path
 * @return string
 */
function url(string $path): string
{
    $path = filter_var(trim($path), FILTER_SANITIZE_SPECIAL_CHARS);
    $url = $path[0] === '/' ? mb_substr($path, 1) : $path;
    $url = $url[mb_strlen($url) - 1] === '/' ? mb_strrchr($url, '/', true) : $url;
    $url = CONF_URL_BASE . '/' . $url;
    return $url;
}

/**
 * ####################
 * ####### VOID #######
 * ####################
 */

/**
 * Redirecionar o usuario para uma url especifica
 * @param string $url
 * @return void
 */
function redirec(string $url): void
{
    header('HTTP/1.1 302 Redirect');

    if (filter_var($url, FILTER_VALIDATE_URL)) {
        header("Location: {$url}");
        exit;
    }

    $location = url($url);

    header("Location: {$location}");
    exit;
}


/**
 * #################
 * ##### CORE ######
 * #################
 */

/**
 * Retorna uma instancia PDO
 * @return PDO
 */
function db(): PDO
{
    return Connect::getInstance();
}


/**
 * Retorna uma instancia Message
 * @return Message
 */
function message(): Message
{
    return new Message();
}


/**
 * Retorna uma instancia Session
 * @return Session
 */
function session(): Session
{
    return new Session();
}


/**
 * #################
 * ##### Model #####
 * #################
 */

/**
 * Retorna uma instancia de User
 * @return User
 */
function user(): User
{
    return new User();
}


/**
 * ##################
 * #### Password ####
 * ##################
 */


/**
 * Retorna hash de password
 * @param string $pass
 * @return string
 */
function passwd(string $pass): string
{
    $passHash = password_hash($pass, CONF_PASS_ALGO, ['cost' => CONF_PASS_COST]);
    return $passHash;
}


/**
 * Compara password
 * @param string $password password sem hash
 * @param string $hash password hash
 * @return bool
 */
function passwd_verify(string $password, string $hash): bool
{
    return password_verify($password, $hash);
}


/**
 * Verifica se o password necessita de rehash
 * @param string $hash
 * @return bool
 */
function passwd_rehash(string $hash): bool
{
    return password_needs_rehash($hash, CONF_PASS_ALGO, ['cost' => CONF_PASS_COST]);
}

/**
 * Generate csrf token
 * @return string
 */
function set_csrf(): string
{
    session()->input_csrf();
    $csrfName = CONF_CSRF_NAME;
    $csrf = session()->$csrfName;
    return "<input type='hidden' name='{$csrfName}' value='{$csrf}' />";
}

/**
 * Valida token csrf
 * @param object $request
 * @return bool
 */
function csrf_verify($request): bool
{
    $csrfName = CONF_CSRF_NAME;
    if (!session()->has($csrfName) || empty($request->$csrfName) || $request->$csrfName !== session()->$csrfName) {
        return false;
    }
    return true;
}