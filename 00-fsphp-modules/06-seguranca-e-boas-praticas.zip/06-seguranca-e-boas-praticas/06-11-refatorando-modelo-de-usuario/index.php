<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("06.11 - Refatorando modelo de usuário");

require __DIR__ . "/../source/autoload.php";

use Source\Models\UserModel;
/*
 * [ find ]
 */

fullStackPHPClassSession("find", __LINE__);
$userModel = new UserModel();

$userExist = $userModel->find('email = :email', 'email=gabriel2@gmail.com');

if ($userExist) {
    var_dump($userExist);
} else {
    echo $userModel->message();
}

$userNotExists = $userModel->find('email = :email', 'email=emailundefined@email');

if ($userNotExists) {
    var_dump($userNotExists);
} else {
    echo $userModel->message();
}

/*
 * [ find by id ]
 */
fullStackPHPClassSession("find by id", __LINE__);

$userById = $userModel->findById(90);
if ($userById) {
    var_dump($userById);
} else {
    echo $userModel->message();
}

/*
 * [ find by email ]
 */
fullStackPHPClassSession("find by email", __LINE__);
$userByEmail = $userModel->findByEmail('test@email.com');
if ($userByEmail) {
    var_dump($userByEmail);
} else {
    echo $userModel->message();
}

/*
 * [ all ]
 */
fullStackPHPClassSession("all", __LINE__);
$users = $userModel->all(5, 1);

if ($users) {
    var_dump($users);
} else {
    echo $userModel->message();
}

/*
 * [ save ]
 */
fullStackPHPClassSession("save create", __LINE__);
$newUser = $userModel->bootstrap('gabriel', 'antunes', 'antunes@email.com', 'asdsad');

if ($newUser) {
    echo message()->info('Antes de salvar');
    var_dump($newUser);

    $userSaved = $newUser->save();

    if ($userSaved) {
        echo message()->success('Usuario criado');
        var_dump($userSaved);
    } else {
        echo $newUser->message();
    }
} else {
    echo $userModel->message();
}

/*
 * [ save update ]
 */
fullStackPHPClassSession("save update", __LINE__);

$userUpdated = $userModel->findByEmail('antunes@email.com');

$userUpdated->password = passwd('123456');

$result = $userUpdated->save();

if ($result) {
    var_dump($result);
} else {
    echo $userUpdated->message();
}