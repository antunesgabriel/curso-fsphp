<?php

spl_autoload_register(function ($class) {
    echo "<span class='tag'>{$class}</span>";

    $base = __DIR__ . '/';
    $source = 'Source\\';
    $length = mb_strlen($source);

    if (strncmp($source, $class, $length) !== 0) {
        return false;
    }

    $classPath = $base . str_replace('\\', '/', mb_substr($class, $length)) . '.php';

    if (file_exists($classPath) && is_file($classPath)) {
        require $classPath;
    }
});