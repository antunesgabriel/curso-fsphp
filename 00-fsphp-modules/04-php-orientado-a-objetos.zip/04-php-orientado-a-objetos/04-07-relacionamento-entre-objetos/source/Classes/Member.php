<?php

namespace Source\Classes;

class Member extends Base
{
    /**
     * @var string $name
     */
    private $name;
    /**
     * @var string $ocupation
     */
    private $ocupation;
    /**
     * @var float $salary
     */
    private $salary;

    public function __construct(string $name, string $ocupation, float $salary)
    {
        $this->name = filter_var($name, FILTER_SANITIZE_STRIPPED);
        $this->ocupation = filter_var($ocupation, FILTER_SANITIZE_STRIPPED);
        $this->salary = filter_var($salary, FILTER_VALIDATE_FLOAT);
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getOcupation(): string
    {
        return $this->ocupation;
    }

    public function getSalary(): float
    {
        return $this->salary;
    }

    public function getFormatSalary(): string
    {
        return 'R$ ' . number_format($this->getSalary(), 2, ',', '.');
    }
}