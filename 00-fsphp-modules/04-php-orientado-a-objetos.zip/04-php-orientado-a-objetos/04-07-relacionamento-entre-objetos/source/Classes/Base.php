<?php

namespace Source\Classes;

class Base
{

    private function notFound($method, $propert, $msg = 'a propiedade')
    {
        echo "<p class='trigger error'>{$method}: {$msg} {$propert} não pode ser acesada desta forma</p>";
    }

    public function __set($name, $value)
    {
        $this->notFound(__FUNCTION__, $name);
    }

    public function __get($name)
    {
        $this->notFound(__FUNCTION__, $name);
    }

    public function __call($methodName, $arguments)
    {
        $this->notFound(__FUNCTION__, $methodName, 'o método');
    }

    public function __unset($name)
    {
        $this->notFound(__FUNCTION__, $name);
    }
}