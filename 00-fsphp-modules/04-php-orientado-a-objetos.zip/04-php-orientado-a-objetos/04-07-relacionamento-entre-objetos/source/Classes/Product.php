<?php

namespace Source\Classes;


class Product extends Base
{
    /**
     * @var string $name
     */
    private $name;
    /**
     * @var float $price
     */
    private $price;

    public function __construct(string $name, float $price)
    {
        $this->name = filter_var($name, FILTER_SANITIZE_STRIPPED);
        $this->price = filter_var($price, FILTER_VALIDATE_FLOAT);
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function  getPrice(): float
    {
        return $this->price;
    }

    public function getFormatPrice(): string
    {
        return 'R$ ' . number_format($this->getPrice(), 2, ',', '.');
    }
}