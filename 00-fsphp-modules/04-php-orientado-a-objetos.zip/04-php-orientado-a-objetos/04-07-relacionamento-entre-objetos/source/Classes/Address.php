<?php

namespace Source\Classes;

class Address extends Base
{
    /**
     * @var string $street
     */
    private $street;
    /**
     * @var int $number
     */
    private $number;
    /**
     * @var string $city
     */
    private $city;

    public function __construct(string $street, string $city, int $number = null)
    {
        $this->street = filter_var($street, FILTER_SANITIZE_STRIPPED);
        $this->city = filter_var($city, FILTER_SANITIZE_STRIPPED);
        $this->number = filter_var($number, FILTER_SANITIZE_NUMBER_INT);
    }

    public function getStreet(): string
    {
        return $this->street;
    }

    public function getCity(): string
    {
        return $this->city;
    }

    public function getNumber(): int
    {
        return $this->number;
    }

    public function getFullAddress(): string
    {
        return "{$this->getStreet()}, numero: {$this->getNumber()}, cidade: {$this->getCity()}";
    }
}