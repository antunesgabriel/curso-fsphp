<?php

namespace Source\Classes;

class Company extends Base
{
    /**
     * @var string $company
     */
    private $company;
    /**
     * @var Address $address
     */
    private $address;
    /**
     * @var array $products
     */
    private $products;

    /**
     * @var array $products
     */
    private $team;


    /**
     * @param string $company
     */
    public function __construct(string $company)
    {
        $this->company = filter_var($company, FILTER_SANITIZE_STRIPPED);
    }

    public function getCompany(): string
    {
        return $this->company;
    }

    public function getAddress(): Address
    {
        return $this->address;
    }

    public function getProducts(): array
    {
        return $this->products;
    }

    public function getTeam(): array
    {
        return $this->team;
    }

    public function setAddress(Address $address)
    {
        $this->address = $address;
    }

    public function setProduct(Product $product)
    {
        $this->products[] = $product;
    }

    public function setMemberTeam(string $name, string $ocupation, float $salary)
    {
        $this->team[] = new Member($name, $ocupation, $salary);
    }
}