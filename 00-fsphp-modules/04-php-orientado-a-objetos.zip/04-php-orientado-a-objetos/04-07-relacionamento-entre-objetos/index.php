<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("04.07 - Relacionamento entre objetos");

require_once __DIR__ . '/source/autoload.php';

use Source\Classes\Company;
use Source\Classes\Address;
use Source\Classes\Product;
use Source\Classes\Member;

/*
 * [ associacão ] É a associação mais comum entre objetos onde o objeto terá um atributo
 * apontando e dando acesso ao outro objeto
 */

/*
 * [ agregação ] Em agregação tornamos um objeto externo parte do objeto base, contudo não
 * o referenciamos em uma propriedade como na associação.
 */

/*
 * [ composição ] Em composição temos um objeto base que é responsável por instanciar o
 * objeto parte, que só existe enquanto o base existir.
 */

$company = new Company('<script>stylus</script>');

var_dump($company);

echo "<p><strong>company: </strong>{$company->getCompany()}</p>";

$address = new Address('Rua praia de itapuã', 'Aracruz', 7);

$company->setAddress($address);

echo "<p class='trigger accept'>
    <strong>o endereço da {$company->getCompany()} é:</strong> {$company->getAddress()->getFullAddress()}
</p>";

// echo $company->getAddress()->street;

$estokay = new Product('Estokay', 39.99);
$rh = new Product('Rh', 34343.98);


$company->setProduct($estokay);
$company->setProduct($rh);

/**
 * @var Product $product
 */
foreach ($company->getProducts() as $product) {
    echo "<p>
        <strong>{$product->getName()}:</strong> {$product->getFormatPrice()}
    </p>";
}

$company->setMemberTeam('Gabriel', 'CEO', 5340.00);
$company->setMemberTeam('Yuri', 'Digital Market', 3460.00);

/**
 * @var Member $member
 */
foreach ($company->getTeam() as $member) {
    echo "<p>
        <strong>Membro:</strong> {$member->getName()} <br />
        <strong>Salário:</strong> {$member->getFormatSalary()}
    </p>";
}

var_dump($company);