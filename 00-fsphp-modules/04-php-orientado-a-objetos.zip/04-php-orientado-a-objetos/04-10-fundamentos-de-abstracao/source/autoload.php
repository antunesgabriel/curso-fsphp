<?php

spl_autoload_register(function ($class) {
    $rootDir = __DIR__ . '/';
    $prefix = 'Source\\';
    $length = mb_strlen($prefix);

    if (strncmp($prefix, $class, $length) !== 0) {
        return false;
    }

    $classPath = str_replace('\\', '/', mb_substr($class, $length));

    $fullPath = $rootDir . $classPath . '.php';

    if (file_exists($fullPath) && is_file($fullPath)) {
        require $fullPath;
    }
});