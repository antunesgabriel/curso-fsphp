<?php

namespace Source\Bank;

use Source\App\User;
use Source\Bank\Account;
use Source\App\Trigger;

class CheckingAccount extends Account
{
    private const IMPOST = 0.6;

    private $limit;

    public function __construct(string $agency, string $account, User $user, float $balance, float $limit)
    {
        parent::__construct($agency, $account, $user, $balance);

        if (!filter_var($limit, FILTER_VALIDATE_FLOAT) || $limit < 0) {
            Trigger::show("Valor de limite invalido: {$this->toBrl($limit)}", Trigger::WARNING);
            $this->limit = 0;
            return;
        }

        $this->limit = $limit;
    }

    public function deposit(float $value)
    {
        if (filter_var($value, FILTER_VALIDATE_FLOAT) && $value > 0) {
            $this->balance += abs($value);
            Trigger::show("O valor {$this->toBrl($value)}, foi depositado com sucesso", Trigger::ACCEPT);
        } else {
            Trigger::show("O valor {$this->toBrl($value)}, não e valido para depósito", Trigger::WARNING);
        }
    }

    public function withdraw(float $value)
    {
        if (filter_var($value, FILTER_VALIDATE_FLOAT) && $value > 0) {
            if ($value <= ($this->balance + $this->limit) || $value <= $this->limit) {

                if ($this->balance > 0) {
                    $valueToWithdraw = $this->balance - $value;
                    $valueWithImpost = $valueToWithdraw < 0 ? abs($valueToWithdraw * self::IMPOST / 100) : 0;

                    $this->balance -= abs($value + $valueWithImpost);

                    $this->limit -= $valueToWithdraw < 0 ? abs($valueToWithdraw) : 0;
                    Trigger::show("Saque efetuado com sucesso!
                    <strong>Valor do saque: {$this->toBrl($value)}</strong>,
                    <strong>Taxa cobrada: {$this->toBrl($valueWithImpost)}</strong>,
                    <strong>Valor total: {$this->toBrl(abs($value +$valueWithImpost))}</strong>
                    ", Trigger::ERROR);
                } else {
                    $this->limit -= abs($value);
                    $valueWithImpost = abs($value * self::IMPOST / 100);
                    $this->balance -= abs($value + $valueWithImpost);

                    Trigger::show("Saque efetuado com sucesso!
                    <strong>Valor do saque: {$this->toBrl($value)}</strong>,
                    <strong>Taxa cobrada: {$this->toBrl($valueWithImpost)}</strong>,
                    <strong>Valor total: {$this->toBrl(abs($value +$valueWithImpost))}</strong>
                    ", Trigger::ERROR);
                }
            } else {
                Trigger::show("Você não pode efetuar o saque no valor de {$this->toBrl($value)} pois
                seu saldo atual é de <strong>{$this->toBrl($this->balance)}</strong> e seu limite é
                {$this->toBrl($this->limit)}", Trigger::WARNING);
            }
        } else {
            Trigger::show("O valor {$value} não é valido", Trigger::WARNING);
        }
    }

    public function getLimit()
    {
        Trigger::show("Seu limite é de {$this->toBrl($this->limit)}");
    }
}