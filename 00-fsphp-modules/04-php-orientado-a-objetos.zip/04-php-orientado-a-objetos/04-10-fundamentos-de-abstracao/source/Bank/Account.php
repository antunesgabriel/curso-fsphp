<?php

namespace Source\Bank;

use Source\App\User;
use Source\App\Trigger;
use Source\Classe;

abstract class Account extends Classe
{
    protected $agency;
    protected $account;
    protected $client;
    protected $balance;


    protected function __construct(string $agency, string $account, User $client, $balance)
    {
        $this->agency = filter_var($agency, FILTER_SANITIZE_STRIPPED);
        $this->account = filter_var($account, FILTER_SANITIZE_STRIPPED);
        $this->client = $client;

        if (filter_var($balance, FILTER_VALIDATE_FLOAT) && $balance > 0) {

            $this->balance = $balance;
        } else {
            $this->balance = 0.00;
            Trigger::show('Valor de depósito inicial invalido!', Trigger::ERROR);
        }
    }

    protected function toBrl(float $value): string
    {
        return 'R$ ' . number_format($value, 2, ',', '.');
    }

    public function extractor()
    {
        $situation = ($this->balance > 0 ? Trigger::ACCEPT : Trigger::ERROR);
        Trigger::show("EXTRATO: Seu saldo é {$this->toBrl($this->balance)}", $situation);
    }

    abstract protected function withdraw(float $value);

    abstract protected function deposit(float $value);
}