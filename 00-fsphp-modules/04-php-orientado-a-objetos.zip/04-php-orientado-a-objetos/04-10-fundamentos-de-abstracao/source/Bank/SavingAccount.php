<?php

namespace Source\Bank;

use Source\Bank\Account;
use Source\App\User;
use Source\App\Trigger;

class SavingAccount extends Account
{
    private $renda;

    public function __construct(string $agency, string $account, User $client, float $balance)
    {
        parent::__construct($agency, $account, $client, $balance);
        $this->renda = 0.006;
    }

    public function withdraw(float $value)
    {
        if (!filter_var($value, FILTER_VALIDATE_FLOAT) || $value <= 0 || $value > $this->balance) {
            Trigger::show(
                "Valor de saque invalído: {$this->toBrl($value)},
                você possui {$this->toBrl($this->balance)} disponiveis para saque",
                Trigger::ERROR
            );
            return;
        }

        $this->balance -= abs($value);

        Trigger::show("Saque de {$this->toBrl($value)} efetuado com sucesso!", Trigger::ERROR);
    }

    public function deposit(float $value)
    {
        if (!filter_var($value, FILTER_VALIDATE_FLOAT) || $value <= 0) {
            Trigger::show("Valor de depósito invalído: {$value}", Trigger::ERROR);
            return;
        }

        $this->balance += abs($value + ($value * $this->renda));

        Trigger::show("Depósito de {$this->toBrl($value)} efetuado com sucesso!", Trigger::ACCEPT);
    }
}