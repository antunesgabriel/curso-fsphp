<?php

namespace Source;

use Source\App\Trigger;

class Classe
{
    public function __set($name, $value)
    {
        Trigger::show("Propiedade <strong>{$name}</strong> não existe.", Trigger::WARNING);
    }

    public function __call($name, $arguments)
    {
        Trigger::show("Método <strong>{$name}</strong> não existe", Trigger::WARNING);
    }
}