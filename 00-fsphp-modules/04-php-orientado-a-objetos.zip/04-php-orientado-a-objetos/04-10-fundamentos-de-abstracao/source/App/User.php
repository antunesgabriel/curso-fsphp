<?php

namespace Source\App;

class User
{
    private $firstName;
    private $lastName;


    public function __construct(string $firstName, string $lastName)
    {
        $this->firstName = filter_var($firstName, FILTER_SANITIZE_STRIPPED);
        $this->lastName = filter_var($lastName, FILTER_SANITIZE_STRIPPED);
    }
}