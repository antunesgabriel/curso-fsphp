<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("04.03 - Qualificação e encapsulamento");

require __DIR__ . '/source/Qualifield/User.php';
// private and public

$user =  new Source\Qualifield\User('Gabriel', 'gabriel@email.com', 'impacta');

// da erro pois são propiedades privadas
// $user->name = 'outro nome';
// $user->email = 'outroemail@email.com.br';
// $user->company = 'impacta';

$feedback = $user->setEmail('gabriel@email.com');
$user->setName('Gabriel<p></p> <script>Antunes</script>');
$user->setCompany('Impacta Web');

var_dump([$user, $feedback]);

$html ="
    <article class='tag'>
        <strong>name: </strong>%s
        <strong>email: </strong>%s
        <strong>company: </strong>%s
    </article>
";

vprintf($html, [$user->getName(), $user->getEmail(), $user->getCompany()]);

/*
 * [ namespaces ] http://php.net/manual/pt_BR/language.namespaces.basics.php
 */
fullStackPHPClassSession("namespaces", __LINE__);

/**
 * definir namespace Source\Classes
 * 
 * usar:
 * require __DIR__ '/source/Classes/Foo.php';
 * 
 * instanciar :
 * $foo = new Source\Classes\Foo();
 * 
 * usando namespace + alias
 * 
 * depois de da require da classe use o USE para poder usar uma alias na classe:
 * 
 * require __DIR__ '/source/Classes/Foo.php';
 * use Source\Classes\Foo;
 * 
 * $foo = new Foo();
 */

 use Source\Qualifield\User;

 $user3 = new User('Antunes', 'antunesgabriel@email.com', '123');

 vprintf($html, [$user3->getName(), $user3->getEmail(), $user3->getCompany()]);


/*
 * [ visibilidade ] http://php.net/manual/pt_BR/language.oop5.visibility.php
 */
fullStackPHPClassSession("visibilidade", __LINE__);

// private, protected and private


/*
 * [ manipulação ] Classes com estruturas que abstraem a rotina de manipulação de objetos
 */
fullStackPHPClassSession("manipulação", __LINE__);

// $user4 = new User('dias', 'dias');

$user4 = new User('dias', 'dias@email.com');

var_dump($user4);