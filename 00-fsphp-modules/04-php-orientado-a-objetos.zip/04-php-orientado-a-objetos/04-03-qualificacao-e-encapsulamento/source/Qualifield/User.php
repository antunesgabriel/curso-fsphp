<?php

namespace Source\Qualifield;

use Error;

class User
{
    private $name = null;
    private $email = null;
    private $company = null;
    private $error = null;

    public function __construct($name, $email, $company = null)
    {
        $this->name = filter_var($name, FILTER_SANITIZE_STRIPPED);

        if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->email = filter_var($email, FILTER_VALIDATE_EMAIL);
        } else {
            $error = new Error('Email invalido');
            $this->setError($error);
        }

        if($company) {
            $this->company = filter_var($company, FILTER_SANITIZE_STRIPPED);
        }
    }

    public function setEmail($email)
    {
        if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->email = $email;
            return true;
        }

        return false;
    }

    public function setName($name)
    {
        $this->name = filter_var($name, FILTER_SANITIZE_STRIPPED);
    }

    public function setCompany($company)
    {
        $this->company = filter_var($company, FILTER_SANITIZE_STRIPPED);
    }

    public function getName()
    {
        return $this->name;
    }

    public function getEmail()
    {
        return $this->email;
    }

    public function getCompany()
    {
        return $this->company;
    }

    private function setError($error)
    {
        $this->error = $error;
    }

    public function getError()
    {
        return $this->error;
    }
}