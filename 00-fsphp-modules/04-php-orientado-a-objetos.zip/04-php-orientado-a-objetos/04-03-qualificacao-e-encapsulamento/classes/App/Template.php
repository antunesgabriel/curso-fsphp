<?php

namespace Classes\App;

class Template
{
    public $app;
}