<?php

namespace Classes\Web;

class Template
{
    public $web;
}