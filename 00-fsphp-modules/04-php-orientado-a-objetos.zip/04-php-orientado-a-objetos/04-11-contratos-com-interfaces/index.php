<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("04.11 - Contratos com interfaces");

require __DIR__ . '/source/autoload.php';

use Source\Classes\User;
use Source\Classes\Admin;
use Source\Classes\Login;
/*
 * [ implementacão ] Um contrato de quais métodos a classe deve implementar
 * http://php.net/manual/pt_BR/language.oop5.interfaces.php
 */

fullStackPHPClassSession("implementacão", __LINE__);

$user = new User('Gabriel', 'Antunes', 'gabriel@email.com.br');

$admin = new Admin('Gabriel', 'Antunes', 'gabriel@email.com.br');

var_dump([$user, $admin]);

/*
 * [ associação ] Um exemplo associando ao login
 */
fullStackPHPClassSession("associação", __LINE__);

$login = new Login();

$login->loginUser($user);
$login->loginAdmin($admin);

// $login->loginAdmin($user) não permitido pois user não é admin
// $login->loginUser($admin) permitido pois admin é user tambem (extende User)

var_dump($login);

/*
 * [ dependência ] Dependency Injection ou DI, é um contrato de relação entre objetos, onde
 * um método assina seus atributos com uma interface.
 */
fullStackPHPClassSession("dependência", __LINE__);

// não funciona pois não implementa UserInterface
// $t = (object) [
//     'getName' => function () {
//         return 'nome';
//     },
//     'getSurname' => function () {
//         return 'nome';
//     },
//     'getEmail' => function () {
//         return 'nome';
//     }
// ];

// $login->login($t);

// Dependency Injection, hibrido pois aceita as objetos que implementam uma interface

$user2 = new User('Antunes', 'Gabriel', 'antunes@email.com');
$admin2 = new Admin('Antunes2', 'Gabriel2', 'antunes2@email.com');

// funciona pois Admin e User implementam UserInterface
$login->login($user2);
$login->login($admin2);

var_dump($login);