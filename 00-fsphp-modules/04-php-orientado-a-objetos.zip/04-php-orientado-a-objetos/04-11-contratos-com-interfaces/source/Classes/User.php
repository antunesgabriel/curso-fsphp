<?php

namespace Source\Classes;

use Source\Interfaces\UserInterface;

// uma clase implementando 2 interfaces dividindo os contratos em blocos
class User implements UserInterface
{
    private $name;
    private $surname;
    private $email;

    public function __construct(string $name, string $surname, string $email)
    {
        $this->name = filter_var($name, FILTER_SANITIZE_STRIPPED);
        $this->surname = filter_var($surname, FILTER_SANITIZE_STRIPPED);
        $this->email = filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : null;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getSurname(): string
    {
        return $this->surname;
    }

    public function getEmail(): string
    {
        return $this->email;
    }
}