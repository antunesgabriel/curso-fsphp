<?php

namespace Source\Classes;

use Source\Interfaces\LoginInterface;
use Source\Interfaces\UserInterface;
use Source\Classes\User;
use Source\Classes\Admin;

class Login implements LoginInterface
{
    private $userLogged;
    private $adminLogged;
    private $login;

    /**
     * Associação com um objeto externo
     */
    public function loginUser(User $user): User
    {
        $this->userLogged = $user;

        return $this->userLogged;
    }

    public function loginAdmin(Admin $admin): Admin
    {
        $this->adminLogged = $admin;

        return $this->adminLogged;
    }

    public function login(UserInterface $user): UserInterface
    {
        $this->login = $user;

        return $this->login;
    }
}