<?php

namespace Source\Classes;

use Source\Classes\User;
use Source\Interfaces\UserInterface;
use Source\Interfaces\ErrorInterface;

class Admin extends User implements UserInterface, ErrorInterface
{
    private $error;
    private $level;

    public function __construct(string $name, string $surname, string $email)
    {
        parent::__construct($name, $surname, $email);

        $this->level = 10;
    }

    public function getError(): string
    {
        return $this->error;
    }

    public function setError(string $error)
    {
        $this->error = filter_var($error, FILTER_SANITIZE_STRIPPED);
    }
}