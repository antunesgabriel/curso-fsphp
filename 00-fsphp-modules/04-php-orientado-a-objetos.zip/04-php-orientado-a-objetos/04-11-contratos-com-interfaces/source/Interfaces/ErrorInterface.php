<?php

namespace Source\Interfaces;

interface ErrorInterface
{
    public function getError(): string;

    public function setError(string $error);
}