<?php

namespace Source\Interfaces;

interface UserInterface
{
    public function getName(): string;

    public function getEmail(): string;

    public function getSurname(): string;
}