<?php

namespace Source\Interfaces;

use Source\Classes\User;
use Source\Classes\Admin;
use Source\Interfaces\UserInterface;

interface LoginInterface
{
    public function loginUser(User $user): User;

    public function loginAdmin(Admin $admin): Admin;

    public function login(UserInterface $user): UserInterface;
}