<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("04.12 - Comportamentos com traits");

require __DIR__ . '/source/autoload.php';

use Source\Classes\Client;
use Source\Classes\Register;
use Source\Classes\ClientAddress;

/*
 * [ trait ] São traços de código que podem ser reutilizados por mais de uma classe. Um trait é como um compoetamento
 * do objeto (BEHAVES LIKE). http://php.net/manual/pt_BR/language.oop5.traits.php
 */

fullStackPHPClassSession("trait", __LINE__);

$client = new Client('Gabriel', 'Antunes', 'antunes@email.com', 1);
$clientAddress = new ClientAddress('rua ai my broW', 11, $client->getId());

$register = new Register($client, $clientAddress);

var_dump($register);

echo "<p class='trigger'>Client: {$register->getClient()->getName()},
Rua: {$register->getClientAddress()->getStreet()}</p>";