<?php

namespace Source\Traits;

use Source\Classes\ClientAddress;

trait ClientAddressTrait
{
    private $clientAddress;


    public function getClientAddress(): ClientAddress
    {
        return $this->clientAddress;
    }

    public function setClientAddress(ClientAddress $clientAddress)
    {
        $this->clientAddress = $clientAddress;
    }
}