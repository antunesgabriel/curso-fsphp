<?php

namespace Source\Traits;

use Source\Classes\Client;

trait ClientTrait
{
    private $client;

    public function getClient(): Client
    {
        return $this->client;
    }

    public function setClient(Client $client)
    {
        $this->client = $client;
    }
}