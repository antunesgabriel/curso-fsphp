<?php

namespace Source\Classes;

class Client
{
    private $name;
    private $surname;
    private $email;
    private $id;

    public function __construct(string $name, string $surname, string $email, int $id)
    {
        $this->name = filter_var($name, FILTER_SANITIZE_STRIPPED);
        $this->surname = filter_var($surname, FILTER_SANITIZE_STRIPPED);

        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->email = $email;
        } else {
            echo '<p class="trigger error">Email invalido</p>';
            $this->email = '';
        }

        $this->id = filter_var($id, FILTER_SANITIZE_NUMBER_INT);
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getSurname(): string
    {
        return $this->surname;
    }

    public function getEmail(): string
    {
        return $this->email;
    }

    public function getId(): int
    {
        return $this->id;
    }
}