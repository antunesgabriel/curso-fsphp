<?php

namespace Source\Classes;


class ClientAddress
{
    private $street;
    private $number;
    private $userId;

    public function __construct(string $street, int $number, int $userId)
    {
        $this->street = filter_var($street, FILTER_SANITIZE_STRIPPED);
        $this->number = filter_var($number, FILTER_SANITIZE_NUMBER_INT);
        $this->userId = filter_var($userId, FILTER_SANITIZE_NUMBER_INT);
    }

    public function getStreet(): string
    {
        return $this->street;
    }

    public function getNumber(): int
    {
        return $this->number;
    }

    public function getUserId(): int
    {
        return $this->userId;
    }
}