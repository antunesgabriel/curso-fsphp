<?php

namespace Source\Classes;

use Source\Traits\ClientTrait;
use Source\Traits\ClientAddressTrait;

use Source\Classes\Client;
use Source\Classes\ClientAddress;

class Register
{
    use ClientTrait;
    use ClientAddressTrait;

    public function __construct(Client $client, ClientAddress $clientAddress)
    {
        $this->setClient($client);
        $this->setClientAddress($clientAddress);
    }
}