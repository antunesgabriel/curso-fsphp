<?php
// registra um autoload
spl_autoload_register(function($class) {
    $provider = 'Source\\'; # pasta que fornece o autoload e onde estão as classes
    $rootDir = __DIR__ . '/';
    $length = mb_strlen($provider);
    $format = '.php';

    /**
     * strncmp($string1, $string2, tamanho)
     * strncmp verifica se as duas strings são parecidas
     * na distancia fornecida, retorn 1 pra sim e 0 pra não
     */

    if(strncmp($provider, $class, $length) !== 0) {
        return false;
    }

    $relativeClass = str_replace('\\', '/', mb_substr($class, $length));

    $filePath = $rootDir . $relativeClass . $format;

    if(!file_exists($filePath) && !is_file($filePath)) {
        return false;
    }

    $className = str_replace('\\', '', mb_strrchr($class, '\\'));

    echo "<p class='trigger accept'>Importada classe {$className} com sucesso!</p>";

    require $filePath;
});