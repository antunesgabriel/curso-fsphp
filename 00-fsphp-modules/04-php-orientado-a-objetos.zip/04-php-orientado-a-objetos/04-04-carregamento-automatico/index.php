<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
// require __DIR__ . '/source/autoload.php'; # autoload feito no curso
require __DIR__ . '/vendor/autoload.php';

/*
 * [ autoload spl psr-4 ] Carregamento de suas classes com spl_autoload psr-4
 */
fullStackPHPClassSession("autoload spl psr-4", __LINE__);

/*
 * [ autoload composer psr-4 ] https://getcomposer.org/doc/00-intro.md
 */

//  require __DIR__ . '/source/Loading/Address.php';
//  require __DIR__ . '/source/Loading/Company.php';
 // require __DIR__ . '/source/Loading/User.php';

 use Source\Loading\Address;
 use Source\Loading\Company;
 use Source\Loading\User;
 use Source\Loading\Foo;

 $user = new User();
 $company = new Company();
 $address = new Address();

 var_dump([
     $user,
     $company,
     $address
 ]);

fullStackPHPClassSession("autoload composer psr-4", __LINE__);

// require __DIR__ . '/vendor/autoload.php'; # import ja feito no inicio do projeto

use PHPMailer\PHPMailer\PHPMailer;

$mailer = new PHPMailer();

var_dump(get_class_methods($mailer));