<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("03.10 - Upload de arquivos");

$folderForUpload = __DIR__ . '/uploads';

if (!file_exists($folderForUpload) || !is_dir($folderForUpload)) {
    mkdir($folderForUpload, 0755);
    echo '<div class="trigger accept">Pasta criada</div>';
}

var_dump([
    'filesize' => ini_get('upload_max_filesize'),
    'postsize' => ini_get('post_max_size')
]);

$maxUpload = ini_get('upload_max_filesize');

var_dump([
    'filetype' => filetype(__DIR__ . '/index.php'), // mostra o tipo de arquivo
    'mime_content_type' => mime_content_type(__DIR__ . '/index.php')
    // mostra o tipo de conteudo do arquivo
]);

include __DIR__ . '/form.php';

/*
 * [ upload ] sizes | move uploaded | url validation
 * [ upload errors ] http://php.net/manual/pt_BR/features.file-upload.errors.php
 */
fullStackPHPClassSession("upload", __LINE__);

/**
 * no formulario tem um parametro na action ./?post=true
 *
 * esse parametro serve pra caso o arquivo enviado estoure o limite do servidor
 * o php saiba que aconteceu uma tentativa de upload.
 *
 * o tipo é INPUT_GET por que o parametro vem na url dando GET na próxima pagina
 * e como query string
 */
$getPost = filter_input(INPUT_GET, 'post', FILTER_VALIDATE_BOOLEAN);

if ($getPost && $_FILES && $_FILES['avatar']['name']) {
    /**
     * seguindo o exemplo como $_POST, $_GET, o $_FILES guarda as informações
     * e os dados de envio de arquivo da request
     */
    $file = $_FILES['avatar'];

    $allowedType = [ // tipos de arquivos permitido para upload
        'application/pdf',
        'image/png',
        'image/jpeg'
    ];

    if (in_array($file['type'], $allowedType)) {
        /**
         * pegando a extenção e criando um nome com um timestamps + extensão do arquivo
         */
        $newNameToFile = time() . mb_strstr($file['name'], '.');

        /**
         * move_uploaded_file(origim, destine)
         *
         * move_upload_file é responsavel pro mover arquivos
         * upados de um lugar para outros, e com apache, os uploads
         * ficam no path $file['tmp_name'], com um nome e sem extensão
         * use move_uploaded_file para mover este arquivo para sua pasta de uploads
         */

        $destine = "{$folderForUpload}/{$newNameToFile}";
        $origin = $file['tmp_name'];

        if (move_uploaded_file($origin, $destine)) {
            echo "<div class='trigger accept'>
                Arquivo enviado com sucesso e salvo como {$newNameToFile}
            </div>";
        } else {
            echo "<div class='trigger error'>
                Ocorreu um erro inexperado ao enviar o arquivo {$file['name']}
            </div>";
        }
    } else {
        echo '<div class="trigger error>Tipo de arquivo não permitido</div>';
    }

    var_dump($file);
} else if ($getPost) {
    echo "<div class='trigger error'>
        Arquivo com tamanho acima do permitido que é {$maxUpload}
    </div>";
} else {
    if ($_FILES) {
        echo '<div class="trigger warning">Por favor selecione um arquivo para envio</div>';
    }
}

var_dump(scandir($folderForUpload));