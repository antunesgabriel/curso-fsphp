<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("03.07 - Manipulação de arquivos");

/*
 * [ verificação de arquivos ] file_exists | is_file | is_dir
 */
fullStackPHPClassSession("verificação", __LINE__);

$filePath = __DIR__ . '/firstFile.txt';

// file_exists(DIRFILE) verifica se existe o arquivo
// is_file(DIRFILE) verifica se o path fornecido é
// de um arquivo (sem ser pasta por exemplo)

if (file_exists($filePath) && is_file($filePath)) {
    echo 'File exists';
} else {
    echo 'File not exists';
}

/*
 * [ leitura e gravação ] fopen | fwrite | fclose | file
 */
fullStackPHPClassSession("leitura e gravação", __LINE__);

if (file_exists($filePath) && is_file($filePath)) {
    $file = file($filePath); // file le o arquivo e retorna uma array com o conteudo
    var_dump([
        'file' => $file,
        // pathinfo retorna a extenção, diretorio, basename, filename
        'pathinfo' => pathinfo($filePath)
    ]);

    echo $file[1];
} else {
    # fopen(FilePath) abre o arquivo para manipular ou ler
    $fileOpen = fopen($filePath, 'w'); // w de ler e escrever
    fwrite($fileOpen, 'Linha 1' . PHP_EOL); // escreve em uma linha
    fwrite($fileOpen, 'Linha 2' . PHP_EOL);
    fclose($fileOpen); // fecha o arquuivo para finalizar a manipulação
}


// feof(OpenFile) retorna true se estiver na ultima linha de leitura do arquivo
// fgets(OpenFile) le o arquivo, uma linha a cada execução
if (file_exists($filePath) && is_file($filePath)) {
    $fileForReader = fopen($filePath, 'r');
    while (!feof($fileForReader)) {
        echo '<p>' . fgets($fileForReader) . '</p>';
    }
    fclose($fileForReader); // lembre-se de sempre fechar o arquivo após a edição
}


/*
 * [ get, put content ] file_get_contents | file_put_contents
 */
fullStackPHPClassSession("get, put content", __LINE__);

// file_get_contents(FilePath)
/**
 * retorna o conteuto do arquivo como string,
 * caso o arquivo não exista retornara um erro
 */

// file_put_contents(FilePath, Content)
/**
 * cria um arquivo no diretório especificado com o conteudo especificado (nos parametros)
 */


$sectionHtml = __DIR__ . '/section.html';

if (file_exists($sectionHtml) && is_file($sectionHtml)) {
    $html = file_get_contents($sectionHtml);
    echo '<h2>Conteúdo do arquivo</h2>';
    echo $html;
} else {
    $content = "
        <section>
            <h3>People</h2>
            <p class='tag'>Name: Antunes Gabriel</p>
            <p class='tag'>Email: email@gabrielantunes.com.br</p>
        </section>
    ";

    file_put_contents($sectionHtml, $content);

    $contentRecovery = file_get_contents($sectionHtml);

    echo $contentRecovery;
}