<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("03.11 - Interação com URLs");

/*
 * [ argumentos ] ?[&[&][&]]
 */
fullStackPHPClassSession("argumentos", __LINE__);

// http_build_query(Array) , o http_build_query, recebe uma array
// e retorna um querystring com as chaves e valores dos indices da array

$arguments = http_build_query([
    'name' => 'Gabriel',
    'company' => 'Stylus',
    'site' => 'http://stylus.com.br',
    'email' => 'stylus@email.com.br',
    'content' => 'g<script>gogogo</script>teste'
]);

echo "<p><a href='./?{$arguments}'>clique</a></p>";

echo '<p><a href="./">limpar</a></p>';

var_dump($_GET);

/*
 * [ segurança ] get | strip | filters | validation
 * [ filter list ] https://php.net/manual/en/filter.filters.php
 */
fullStackPHPClassSession("segurança", __LINE__);

$dataValidade = [
    'name' => FILTER_SANITIZE_STRIPPED,
    'company' => FILTER_SANITIZE_STRIPPED,
    'site' => FILTER_SANITIZE_STRIPPED,
    'email' => FILTER_SANITIZE_STRIPPED,
    'content' => FILTER_SANITIZE_STRIPPED
];

$datas = filter_input_array(INPUT_GET, $dataValidade);

if ($_GET) {
    if ($datas && in_array(['', false], $datas)) {
        echo '<p class="trigger warning">Informe todos os campos</p>';
    } else if (!filter_var($datas['email'], FILTER_VALIDATE_EMAIL)) {
        echo '<p class="trigger warning">Informe um email valido</p>';
    } else if (!filter_var($datas['site'], FILTER_VALIDATE_URL)) {
        echo '<p class="trigger warning">Informe uma url valida</p>';
    } else {
        echo '<p class="trigger accept">Cadastro efetuado</p>';
    }
}

var_dump($datas);