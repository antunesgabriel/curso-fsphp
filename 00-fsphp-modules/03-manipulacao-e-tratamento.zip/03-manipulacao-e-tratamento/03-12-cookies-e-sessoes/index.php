<?php
ob_start();

require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("03.12 - Cookies e sessões");

/*
 * [ cookies ] http://php.net/manual/pt_BR/features.cookies.php
 */
fullStackPHPClassSession("cookies", __LINE__);

//setcookie(nome, valor, tempo); > cria um cookie;
/**
 * cookies e sessões são setados em uma camada acima, então uma vez criados,
 * eles podem ser consultados mesmo sem estar presentes
 */
var_dump($_COOKIE);

// criando um cookie
// setcookie('firstcookie', 'this is my first cookie em php', strtotime('+60seconds'));
// setcookie('phpcookie', 'this is my second cookie', strtotime('+60seconds'));

// removendo cookie
// setcookie('firstcookie', null, strtotime('-60seconds'));
// setcookie('phpcookie', null, strtotime('-60seconds'));

// acessando um cookie alem de sar $_COOKIE

$cookies = filter_input_array(INPUT_COOKIE, FILTER_SANITIZE_STRIPPED);

var_dump($cookies);

// $time = time() + 60 * 60 * 24; # 1 dia;
//ou 
$time = strtotime('+1days');

// criando valores para um cookie
$user = [
    'user' => 'gabriel dias teixeira antunes',
    'passwd' => '123456',
    'expire' => $time
];

setcookie(
    'stu',
    http_build_query($user),
    $time,
    '/',
    'localhost',
    true
);

$login = filter_input(INPUT_COOKIE, 'stu', FILTER_SANITIZE_STRIPPED);

if($login) {
    parse_str($login, $userData); // recebendos os dados em querystring
    var_dump($userData);
}

/*
 * [ sessões ] http://php.net/manual/pt_BR/ref.session.php
 */
fullStackPHPClassSession("sessões", __LINE__);

$sessionFolder = __DIR__ . '/ssn';

if(!file_exists($sessionFolder) || !is_dir($sessionFolder)) {
    mkdir($sessionFolder, 0755);
}

/**
*session_start(?['cookie_lifetime' => 10000])
*função para starta a sessão no php, pode receber 
*uma array como parametro, contendo sua configuração,
* como tempo de vida do cookie
*/

/**
 * session_save_path(DIR)
 * configuração pra definir local onde as session irão ficar.
 * Se não receber parametro, retorna a pasta onde esta sendo salva
 * as sessions
 */

 /**
  * session_name('NomeDaSession')
  * configura o nome da sessão. Se invocada sem argumento,
  * retorna o nome configrado das sessions
  */

session_save_path($sessionFolder);
session_name('FSPHPSESSION');
session_start([
    'cookie_lifetime' => (60 * 60 * 4) # opcional
]);

var_dump($_SESSION, [
    'session_id' => session_id(),
    'session_status' => session_status(),
    'session_name' => session_name(),
    'session_save_path' => session_save_path(),
    'session_get_cookie' => session_get_cookie_params() # retorna informações do session cookie
]);

$user = (object) [
    'name' => 'gabriel',
    'email' => 'gabrielantunescontato@gmail.com',
    'birthDate' => '22/12/1996'
];

$workspace = (object) [
    'company' => 'Stylus',
    'email' => 'stylus@email.com'
];

// adcionando dados na session
$_SESSION['user'] = $user;
$_SESSION['workspace'] = $workspace;

// removendo um dado da session
//unset($_SESSION['user']);

$ssuser = $_SESSION['user'];
$sswork = $_SESSION['workspace'];

echo "<span class='tag'>{$ssuser->name}</span>";
echo "<span class='tag'>{$sswork->company}</span>";

// destruindo dados da session
// session_destroy()

ob_end_flush();
?>