<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("03.03 - Funções para arrays");

/*
 * [ criação ] https://php.net/manual/pt_BR/ref.array.php
 */
fullStackPHPClassSession("manipulação", __LINE__);

$array = [
    'Fetty Wap',
    'Tyga',
    'Juice wrld'
];

$nominalArray = [
    'artist1' => 'Fetty Wap',
    'artist2' => 'Tyga',
    'artist3' => 'Juice wrld',
];

// adcionar items ao inicio da array

// em array "normais": array_unshift(Array, ...items);
array_unshift($array, '', 'Shodie Shodie');

// em arrays associativa (nominal)

$nominalArray = ['artist4' => '', 'artist5' => 'Shodie Shodie'] + $nominalArray;

// adcionar ao final da array
array_push($array, '', 'Lil Tecca');

$nominalArray = $nominalArray + [
    'artist6' => '',
    'artist7' => 'Lil Tecca'
];

// retirar item do inicio da array
array_shift($array);
array_shift($nominalArray);

// retirar item do final da array
array_pop($array);
array_pop($nominalArray);

$array = array_filter($array); // filter tira da array os indices com valores vazios
$nominalArray = array_filter($nominalArray);

var_dump([
    $array,
    $nominalArray
]);


/*
 * [ ordenação ] reverse | asort | ksort | krsort | sort | rsort
 */
fullStackPHPClassSession("ordenação", __LINE__);


$arrayOrder = $array;
$nominalOrder = $nominalArray;

$arrayOrder = array_reverse($arrayOrder); // reverte a ordem da array, não mantem indices
$nominalOrder = array_reverse($nominalOrder); // reverte a ordem da array e mantem indices

asort($arrayOrder); // ordena por valores e mantem os indices
asort($nominalOrder); // ordena por valores e mantem os indices

ksort($arrayOrder); // ordena por key
ksort($nominalOrder); // ordena por key

krsort($arrayOrder); // ordena por key e de forma reversa
krsort($nominalOrder); // ordena por key e de forma reversa

sort($arrayOrder); // ordena por valores e altera os indices
// sort($nominalOrder); // ordena por valores e muda os indices de nominal para normais

asort($nominalOrder);

// rsort() como o sort() porem reverso

var_dump([
    $array,
    $nominalArray,

    # array manipuladas
    $arrayOrder,
    $nominalOrder
]);


/*
 * [ verificação ]  keys | values | in | explode
 */
fullStackPHPClassSession("verificação", __LINE__);

# in_array('OQue?', Array) busca o item nos VALORES da array

if (in_array('Fetty Wap', $nominalArray) && in_array('Fetty Wap', $arrayOrder)) {
    echo '<p>Tem Fetty Wap nas duas arrays</p>';
}

if (in_array('artist8', array_keys($nominalOrder))) {
    echo '<p>Tem a chave artist8 na array</p>';
} else {
    echo '<p>Não tem a chave artist8 na array</p>';
}


/**
 * [ exemplo prático ] um template view | implode
 */
fullStackPHPClassSession("exemplo prático", __LINE__);

$content = [
    'userAvatar' => 'https://api.adorable.io/avatars/179/abott@adorable.png',
    'userName' => 'Nareba',
    'userEmail' => 'nareba@email.com'
];

$html = <<<HTML
    <style>
        .avatar {
            height: 128px;
            width: 128px;
            border-radius: 50%;
            margin: 0 auto;
            border: 2px solid grey;
        }

        .avatar img {
            max-width: 100%;
            border-radius: 50%;
        }
    </style>
    <main>
        <div class="avatar">
            <img src="{{ userAvatar }}" alt="user avatar" />
        </div>

        <p>
            <strong>nome:</strong> {{ userName }}
        </p>

        <p>
            <strong>email:</strong> {{ userEmail }}
        </p>
    </main>
HTML;

$keysToString = '{{ ' . implode(' }}&{{ ', array_keys($content)) . ' }}';

$template = str_replace(explode('&', $keysToString), array_values($content), $html);

echo $template;