<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("03.05 - Manipulação de datas");

/*
 * [ a função date ] setup | output
 * [ date ] https://php.net/manual/pt_BR/function.date.php
 * [ timezones ] https://php.net/manual/pt_BR/timezones.php
 */
fullStackPHPClassSession("a função date", __LINE__);

$paragraph = "<p class='tag'>%s</p>";

printf($paragraph, 'Timezone: ' . date_default_timezone_get()); // obter timezone // America/Sao_Paulo

printf($paragraph, 'Data: ' . date('d/m/Y ')); // date($format, $time?) função que retorna uma data
printf($paragraph, 'Horas: ' . date('H:i:s'));
printf($paragraph, date(DATE_W3C)); // php tem constantes com formatos prontos
printf($paragraph, strtotime('-1hours'));
printf($paragraph, date('d/m/Y H:i:s'));

// date_default_timezone_set(Timezone) // definir um timezone pro servidorr
// time() obtem timestamp utc

var_dump([
    'time' => time(),
]);

/**
 * [ string to date ] strtotime | strftime
 */
fullStackPHPClassSession("string to date", __LINE__);

//strtotime(StringArgumento) recebe como parametros
//string que são usadas como comandos para manipula o time utc
// como o +3days que adciona mais 3 dias a partir do time utc momentaneo
// temos tbm hours, minutes, days, years...

$myCurrentTime = time();

printf($paragraph, strtotime('+1months'));
printf($paragraph, date(DATE_W3C, strtotime('+1months', $myCurrentTime))); // combo com date para formata o tempo
printf($paragraph, date('d/m/Y H:i:s', strtotime('+1months', $myCurrentTime)));
printf('<p>%s</p>', date('d/m/Y H-i-s'));

//strftime(Template)
/**
 * strftime recebe uma string como printf, só que ao invés de %s,
 * ele usa %d, %m, %Y, %H, %I, %S que são substituido pelo dia, mes, ano, horas,
 * minutos e segundos no momento, pelo própio strftime
 */

 $stringTime = '<p>Hoje é dia %d, do mês %m de %Y. São %H horas, %M minutos e %S segundos</p>';

 echo strftime($stringTime);