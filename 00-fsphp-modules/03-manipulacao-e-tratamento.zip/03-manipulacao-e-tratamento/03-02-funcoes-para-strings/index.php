<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("03.02 - Funções para strings");

/*
 * [ strings e multibyte ] https://php.net/manual/en/ref.mbstring.php
 */
fullStackPHPClassSession("strings e multibyte", __LINE__);

$string = 'O último show do AC/DC foi íncrivel!';

var_dump([
    'string' => $string,
    'strlen' => strlen($string), #conta acentos como caracter
    'mb_strlen' => mb_strlen($string), #ñ conta acentos como caracter (Use este oara pt-br)
    'substr' => substr($string, 9), # conta acento como caracter
    'mb_substr' => mb_substr($string, 9) # ñ conta acentuo como caracter
]);

// resumo use mb_ (multibyte) para tratar strings que possuam acentuação]
// em geral use mb_ para tartar palavras em portugues

/**
 * [ conversão de caixa ] https://php.net/manual/en/function.mb-convert-case.php
 */
fullStackPHPClassSession("conversão de caixa", __LINE__);

var_dump([
    # Passa a string para Caixa alta
    'strtoupper' => strtoupper($string), // nesse caso os caracter com acentos não vão pra caixza alta
    'mb_strtoupper' => mb_strtoupper($string),
    'mb_strtolower' => mb_strtolower($string),

    # a function mb_convert_case(String, Case)
    # converte o case da string de acordo com o tipo passado
    # (MB_CASE_UPPER, MB_CASE_LOWER, MB_CASE_TITLE)
    'mb_convert_case UPPER' => mb_convert_case($string, MB_CASE_UPPER),
    'mb_convert_case LOWER' => mb_convert_case($string, MB_CASE_LOWER),
    'mb_convert_Case TITLE' => mb_convert_case($string, MB_CASE_TITLE)
]);



/**
 * [ substituição ] multibyte and replace
 */
fullStackPHPClassSession("substituição", __LINE__);

$mbString = $string;
$mbString2 = 'teste , echo , teste , casa';

var_dump([
    'mb_strlen' => mb_strlen($mbString), // tamanho da string
    // procura por algo na string , retornando ou o index se achar ou false se não achar
    // retorna o indice de onde comeca a ocorrencia do primeiro que ele achar
    'mb_strpos' => mb_strpos($mbString, 'show'),

    // o msm do mb_strpos, porem retorna onde começa a ULTIMA ocorrência
    'mb_strrpos' => mb_strrpos($mbString, 'show'),

    // mb_substr(String, IndiceDeOndeOCorteComeça, LarguraDoCorte)
    // retorna o pedaço especifico do corte.
    'mb_substr' => mb_substr($mbString, 9, 4), // show
    'mb_strstr' => mb_strstr($mbString, 'AC/DC'), // pega string a partir de 'AC/DC' //'foi íncrivel!'
    'mb_strstr' => mb_strstr($mbString, 'AC/DC', true), // 'O último show do '
    // passando true como terceiro parametro retorna a string antes do ponteiro indicado
    'mb_strchr' => mb_strrchr($mbString2, ' , ') // retorna a partir da ultima
    // ocorrencia do ponteiro // , casa
]);

$mbReplace = $string;
$cpf = '198.753.785-45';

var_dump([
    /**
     * str_repalce(OQueDeveSerSubstituidoNaString, PeloOq, String)
     * str_repalce substitui a ocorrencia passada pelo valor passado
     */
    'str_replace' => str_replace('AC/DC', 'Fresno', $mbReplace),
    'clearCpf' => str_replace(['.', '-'], '', $cpf)
]);

$template = <<<HTML
    <article>
        <h2>{{ title }}</h2>
        <p>
            <strong>Nome: </strong> {{ name }}
        </p>
        <p>
            <strong>Email: </strong> {{ email }}
        </p>
    </article>
HTML;

$content = [
    'title' => 'Front End',
    'name' => 'Gabriel Antunes',
    'email' => 'gabriel@email.com.br'
];


$html = str_replace([
    '{{ title }}',
    '{{ name }}',
    '{{ email }}'
], array_values($content), $template);

echo $html;

$html2 = str_replace(
    explode('&', '{{ ' . implode(' }}&{{ ', array_keys($content)) . ' }}'),
    array_values($content),
    $template
);

echo $html2;




/**
 * [ parse string ] parse_str | mb_parse_str
 */
fullStackPHPClassSession("parse string", __LINE__);

// mb_parse_str(String, $output)
// interpretar dados em strings, como query strings etc

$endpoint = 'book=rapoza&capa=dura';

mb_parse_str($endpoint, $urlParsed);

var_dump(
    $endpoint,
    $urlParsed,
    (object) $urlParsed
);

$url = 'https://ebooks.com.br/busca?book=Lord+Of+Rings&capa=dura';

$query = mb_substr($url, mb_strpos($url, '?') + 1);

mb_parse_str(str_replace('+', ' ', $query), $queryParsed);

var_dump([
    'query' => (object) $queryParsed
]);