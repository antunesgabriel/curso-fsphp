<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("03.04 - Manipulação de objetos");

/*
 * [ manipulação ] http://php.net/manual/pt_BR/language.types.object.php
 */
fullStackPHPClassSession("manipulação", __LINE__);

$profile = (object) [ // criando objeto dinamico (stdClass)
    'name' => 'Gabriel',
    'company' => 'Stylus',
    'email' => 'contato@stylus.com.br'
];

// acessando propiedades de um objeto:

echo "
    <p class='tag'>
        Nome: {$profile->name}<br />
        Company: {$profile->company}<br />
        Email: {$profile->email}
    </p>
";

$clone = $profile;

unset($clone->email); // apagar um propiedade de um objeto


$company = new StdClass();

$company->company = 'Stylus';
$company->ceo = $profile;
$company->manager = new StdClass();
$company->manager->name = 'Yuri';
$company->manager->email = 'yuri@contato.com.br';

var_dump([
    $profile,
    $clone,
    $company
]);

$date = new DateTime();

class Teste extends DateTime
{ }

$classForTest = new Teste();

var_dump([
    'class' => get_class($date), // Nome da class
    'class2' => get_class($company),
    'list methods' => get_class_methods($date),
    'list vars' => get_object_vars($date),

    // retorna o parent da classe (quem ela herda), se não tiver retorna false
    // aqui retorn DateTime
    'parent' => get_parent_class($classForTest),

    // retorn true, is_subclass_of, verifica se um objeto é uma subclass
    'check parent' => is_subclass_of($classForTest, 'DateTime')
]);

/**
 * [ análise ] class | objetcs | instances
 */
fullStackPHPClassSession("análise", __LINE__);