<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("03.09 - Formuários e filtros");

/*
 * [ request ] $_REQUEST
 * https://php.net/manual/pt_BR/book.filter.php
 */
fullStackPHPClassSession("request", __LINE__);

$form = new StdClass();

$form->name = 'gabriel';
$form->mail = 'antunesgabriel@email.com';

var_dump($_REQUEST); // request guarda informações da request
// request é muito permissivel, e não é muito bom trabalhar com ele em aplicaçoes;
// Use o $_POST ou $_GET;

$form->method = 'POST';

include __DIR__ . '/form.php';


/*
 * [ post ] $_POST | INPUT_POST | filter_input | filter_var
 */
fullStackPHPClassSession("post", __LINE__);

// $_POST guarda as informações da requisições tipo post;

var_dump($_POST);


// filter_input(INPUT_TYPE, 'NomeDoCampo', FILTER_TYPE);
/**
 * o filter_input faz um filtro do campo especificado e retorna
 * o nome do campo como chave e ovalor dele caso seja
 * validado pelo filtro, se não for retorna null.
 * filter_input ele recebe as informações da request, e as tratas
 * com o que foi especificado
 */
$name = filter_input(INPUT_POST, 'name', FILTER_DEFAULT);
// O FILTER_DEFAULT é um filtro genérico que não tem uma validação
// usado somente pra completa sintax do filter_input e filter_input_array
// o php possui diversos filtros prontos como email e etc...


//filter_input_array(INPUT_TYPE, FILTER_TYPE)
/**
 * como o filter_input, porem ele não filtra um campo especifico,
 * ele filtra todos os campos da request, usando o filter_type especificado,
 * e retorna uma array com nome do campo e o valor dele, caso seja validado pelo filtro
 */
$formValues = filter_input_array(INPUT_POST, FILTER_DEFAULT);

var_dump([
    $name,
    $formValues
]);

if($formValues) {
    if(in_array('', $formValues)) {
        echo '<p class="trigger warning">Preencha todos os campos</p>';

        // filter_var, é como filter_input, porem recebe um variavel e realiza um filtro nela
        // filter_var(Var, FilterType)
    } else if(!filter_var($formValues['mail'], FILTER_VALIDATE_EMAIL)) {
        echo '<p class="trigger warning">Informe um email valido</p>';
    } else {
        //array_map(callback, Array)
        /**
         * array_map é como o map do javascript, ele mapeia
         * uma array para outra, recebe o nome da função como callback
         * e retorna um nova array
         */

         /**
          * 'strp_tags' é o nome de uma user function do php
          * que remove todos as tags de uma string , e a retorna sem as tag
          */

          /**
           * 'trim' é uma user function que recebe um string
           * e retorna ela sem espaços desnecessarios como: 'gabriel      '
           */
        $save = array_map('strip_tags', $formValues);
        $save = array_map('trim', $save);
        echo '<p class="trigger accept">Salvo com sucesso.</p>';
        var_dump(['save' => $save]);
    }
}

$form->method = 'POST';

include __DIR__ . '/form.php';

/*
 * [ get ] $_GET | INPUT_GET | filter_input | filter_var
 */
fullStackPHPClassSession("get", __LINE__);

$form->method = 'GET';
include __DIR__ . '/form.php';

var_dump($_GET);


$getName = filter_input(INPUT_GET, 'name', FILTER_SANITIZE_STRING); //com filtro
$arrayGet = filter_input_array(INPUT_GET, FILTER_DEFAULT); // sem filtro

var_dump([
    $getName,
    $arrayGet
]);


if($getName) {
    echo '<p class="trigger accept">Você digitou um nome</p>';
}

if($arrayGet) {
    if(in_array('', $arrayGet)) {
        echo '<p class="trigger warning">Preecha todos os campos</p>';
    } else if(!filter_var($arrayGet['mail'], FILTER_VALIDATE_EMAIL)) {
        echo '<p class="trigger warning">Informe um email invalido</p>';
    } else {
        $save = array_map('strip_tags', $arrayGet);
        $save = array_map('trim', $save);
        echo '<p class="trigger accept">Busca feita com sucesso!</p>';
        var_dump([
            'arrayGet' => $arrayGet,
            'save' => $save,
            'getName' => $getName
        ]);
    }
}


/*
 * [ filters ] list | id | var[_array] | input[_array]
 * http://php.net/manual/pt_BR/filter.constants.php
 */
fullStackPHPClassSession("filters", __LINE__);

var_dump([
    'filter_list()' => filter_list(),
    'filter_id' => filter_id('int')
]);

/**
 * filter_list() retorna uma lista com nome de filtros do php
 * filter_id('filtername') recebe o nome de um filtro e retorna o id dele
 */

 // Como aplicar filtros para cada campo em filter_input_array e filter_var_array

/**
 * aqui eu fiz uma array com o nome dos campos e o
 * filtro que deve ser aplicado a este campo
 */
$filtros = [ 
    'name' => FILTER_SANITIZE_STRIPPED,
    'mail' => FILTER_VALIDATE_EMAIL // ser NAÕ FOR VALIDO ESSE CAMPO RETORNA FALSE
];

$data = filter_input_array(INPUT_GET, $filtros);
 // passou o array de filtros como tipo de filtro para filter_input_array(INPUT_TYPE, FILTERS)

 /**
  * para filter_var_array é você também pode pasar uma array com filtros
  * para cada campo
  */

  $filtros2 = [
    'name' => FILTER_SANITIZE_STRING,
    'mail' => FILTER_SANITIZE_EMAIL // passa o valor para string ou seu equivalente em string
  ];

  $data2 = filter_var_array($data, $filtros2);

var_dump([
    'input filters output' => $data,
    'var filters output' => $data2
]);