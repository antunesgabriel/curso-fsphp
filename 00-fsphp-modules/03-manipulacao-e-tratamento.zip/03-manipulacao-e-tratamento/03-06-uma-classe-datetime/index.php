<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("03.06 - Uma classe DateTime");

/*
 * [ DateTime ] http://php.net/manual/en/class.datetime.php
 */
fullStackPHPClassSession("A classe DateTime", __LINE__);

define('DATE_BR', 'd/m/Y H:i:s');

$dateNow1 = new DateTime();

$staticDate = DateTime::createFromFormat(DATE_BR, date('22/12/2020 12:00:00'));

var_dump([
    $dateNow1,
    # get_class_methods($dateNow1) obter metodos de uma classe
    $staticDate
]);


$newTimeZone = new DateTimeZone('Pacific/Apia');
$dateNow2 = new DateTime('now', $newTimeZone);

# Manipulando datas
var_dump([
    $dateNow1->format(DATE_BR),
    $dateNow1->format('d'),
    $dateNow2->format(DATE_BR),
    // $dateNow2
]);


/*
 * [ DateInterval ] http://php.net/manual/en/class.dateinterval.php
 * [ interval_spec ] http://php.net/manual/en/dateinterval.construct.php
 */
fullStackPHPClassSession("A classe DateInterval", __LINE__);

$dateInterval = new DateInterval('P1Y5MT10H43M'); // P periodo T tempo
$dateNow3 = new DateTime();
// $dateNow3->add($dateInterval); // adcionando um intervalo de tempo
$dateNow3->sub($dateInterval);
var_dump([
    $dateNow3,
    // $dateInterval
]);

$birth = new DateTime(date('Y') . '-12-22');
$dateNow4 = new DateTime('now');

$diff = $dateNow4->diff($birth);

var_dump([
    // $diff, diferença entre as datas
    $birth->format(DATE_BR),
    $diff->days
]);

if($diff->invert) {
    echo "<p>Seu aniversário foi a {$diff->days} dias</p>";
} else {
    echo "<p>Seu aniversário será daqui a {$diff->days} dias</p>";
}

$dateNow5 = new DateTime();
var_dump([
    $dateNow5->format(DATE_BR),
    // add(Interval) 
    $dateNow5->add(DateInterval::createFromDateString('5hours'))->format(DATE_BR),
    // sub(Interval)
    $dateNow5->sub(DateInterval::createFromDateString('5hours'))->format(DATE_BR)
]);

/**
 * [ DatePeriod ] http://php.net/manual/pt_BR/class.dateperiod.php
 */
fullStackPHPClassSession("A classe DatePeriod", __LINE__);

define('DATE_FINALLY', '2020-12-22');

$init = new DateTime('now');
$interval = new DateInterval('P1M');
$end = new DateTime(DATE_FINALLY);

$periods = new DatePeriod($init, $interval, $end);
$periods->include_start_date;

var_dump([
    'start' => $init->format(DATE_BR),
    'interval' => $interval->m,
    'end' => $end->format(DATE_BR)
], $periods);

foreach($periods as $recurence) {
    echo "<span class='tag'>{$recurence->format(DATE_BR)}</span>";
}