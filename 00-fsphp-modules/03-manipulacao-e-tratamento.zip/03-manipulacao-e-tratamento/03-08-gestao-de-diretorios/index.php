<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("03.08 - Gestão de diretórios");

/*
 * [ verificar, criar e abrir ] file_exists | is_dir | mkdir  | scandir
 */
fullStackPHPClassSession("verificar, criar e abrir", __LINE__);
// file_exists(Path) verifica se a pasta existe
//  is_dir(Path) verifica se o arquivo é uma pasta
// mkdir(Path, mode) cria o arquivo na path especificada e com o mode( permições) especificada exe: 0777, 0755
// scandir(Path) scaneia a pasta

$firstFolder = __DIR__ . '/firstFolder';

if (file_exists($firstFolder) && is_dir($firstFolder)) {
    echo '<p>Pasta já existe</p>';
} else {
    mkdir($firstFolder, 0755);
}

var_dump(scandir($firstFolder));

/*
 * [ copiar e renomear ] copy | rename
 */
fullStackPHPClassSession("copiar e renomear", __LINE__);

$uploads = __DIR__ . '/uploads';
$tmp = __DIR__ . '/tmp';
$file = __DIR__ . '/uploads/file.txt';

if (!file_exists($uploads) || !is_dir($uploads)) {
    mkdir($uploads, 0755);
} else {
    echo '<p> Pasta uploads já existe</p>';
}

if (!file_exists($tmp) || !is_dir($tmp)) {
    mkdir($tmp, 0755);
} else {
    echo '<p>Pasta tmp já, existe</p>';
}


if (!file_exists($file) || !is_file($file)) {
    $fileOpen = fopen($file, 'w');
    fclose($fileOpen);
} else {
    echo '<p>File já existe</p>';
}

$cpFileToTmp = __DIR__ . '/tmp/file-copy.txt';

if (!file_exists($cpFileToTmp) || !is_file($cpFileToTmp)) {
    copy($file, $cpFileToTmp);
    echo '<p>Arquivo copiado!</p>';
} else {
    echo 'Copia já existe';
}

$pathInfo = pathinfo($file);
$time = time();
$ext = $pathInfo['extension'];
$fileName = $pathInfo['filename'];

$rename = __DIR__ . "/tmp/{$fileName}-{$time}.{$ext}";

if (!file_exists($rename) || !is_file($rename)) {
    rename($file, $rename);

    echo '<p>Arquivo renomeado e movido com sucesso</p>';
} else {
    echo '<p>Arquivo não pode ser criado</p>';
}

/*
 * [ remover e deletar ] unlink | rmdir
 */
fullStackPHPClassSession("remover e deletar", __LINE__);

$rootDir = __DIR__;
$removeDir = $rootDir . '/remove';

if(!file_exists($removeDir) || !is_dir($removeDir)) {
    mkdir($removeDir, 0755);
}

var_dump(
    scandir($rootDir),
    scandir($removeDir)
);

$filesInRemoveDir = array_diff(scandir($removeDir), ['.', '..']);

if(count($filesInRemoveDir) >= 1) {
    echo '<h2>Clear...</h2>';

    foreach($filesInRemoveDir as $fileForRemove) {
        $fileForRemove = "{$removeDir}/{$fileForRemove}";

        if(file_exists($fileForRemove) && is_file($fileForRemove)) {
            unlink($fileForRemove);
            continue;
        } else if(file_exists($fileForRemove) && is_dir($fileForRemove)) {
            rmdir($fileForRemove);
        } else {
            var_dump(
                $fileForRemove,
                file_exists($fileForRemove),
                is_file($fileForRemove),
                is_dir($fileForRemove)
            );
        }
    }
}

echo '<h2>Arquivos da pasta remove foram removidos.</h2>';

echo '<h2>Limpando Pasta remove...</h2>';

if(file_exists($removeDir) && is_dir($removeDir)) {
    rmdir($removeDir);
    echo '<p>Pasta <strong>remove</strong> removida com sucesso!</p>';
} else {
    echo '<p>Não existe a pasta remove</p>';
}


if(file_exists($tmp) && is_dir($tmp)) {
    $filesInTmp = array_diff(scandir($tmp), ['.', '..']);

    if(count($filesInTmp) >= 1) {
        /**
         * ISSO PODERIA SER UMA FUNÇÃO PARA EVITAR REPETIÇÕES,
         * PORÉM ESTOU REPETINDO PARA PRATICAR. =D
         */

         foreach ($filesInTmp as $fileTmp) {
             $fileTmp = "{$tmp}/{$fileTmp}";

            $exist = file_exists($fileTmp);

             if($exist && is_file($fileTmp)) {
                unlink($fileTmp);
             } else if ($exist && is_dir($fileTmp)) {
                rmdir($fileTmp);
             }

             echo '<span class="tag">Arquivo removido</span> ';
         }
    }
    echo '<h2>Pasta tmp está limpa</h2>';
}

var_dump(scandir($rootDir));