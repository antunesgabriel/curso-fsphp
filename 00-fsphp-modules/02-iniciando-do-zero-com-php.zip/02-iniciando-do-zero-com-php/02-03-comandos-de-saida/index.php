<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("02.03 - Comandos de saída");

/**
 * [ echo ] https://php.net/manual/pt_BR/function.echo.php
 */
fullStackPHPClassSession("echo", __LINE__);

echo '<h4>Teste <span class="tag">echo</span> simples</h4>',
    '<p>Comando: <strong>echo "Teste echo simples"</strong>;</p>';

$hello = 'Hello Word';
$tag = '<span class="tag">#BoraProgramar!</span>';

echo("<p>{$hello}, {$tag}</p>");

/**
 * [ print ] https://php.net/manual/pt_BR/function.print.php
 */
fullStackPHPClassSession("print", __LINE__);

print('<h4>Teste <span class="tag">print</span></h4>');


/**
 * [ print_r ] https://php.net/manual/pt_BR/function.print-r.php
 */
fullStackPHPClassSession("print_r", __LINE__);

$array = [
    'scholl' => 'UpInside',
    'course' => 'FSPHP UpInside'
];

echo '<pre>', print_r($array, true), '</pre>';

/**
 * [ printf ] https://php.net/manual/pt_BR/function.printf.php
 */
fullStackPHPClassSession("printf", __LINE__);

$template = "
    <article>
        <h2>%s</h2>
        <p>%s</p>
    </article>
";

$title = "{$hello} {$tag}";
$content = "Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Vivamus semper pharetra eros, ut fermentum mauris. Mauris eget quam nulla.
Praesent eu massa dictum, interdum urna eu, euismod est.";

printf($template, $title, $content);

$articleHtml = sprintf($template, "Hello Word Guardado! {$tag}", $content);

echo $articleHtml;

/**
 * [ vprintf ] https://php.net/manual/pt_BR/function.vprintf.php
 */
fullStackPHPClassSession("vprintf", __LINE__);

$template2 = "
    <article>
        <h2>Escola: %s</h2>
        <h3>Curso: %s</h3>
    </article>
";

vprintf($template2, $array);

/**
 * [ var_dump ] https://php.net/manual/pt_BR/function.var-dump.php
 */
fullStackPHPClassSession("var_dump", __LINE__);

var_dump($array);
