<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("02.07 - Estruturas de controle");

/*
 * [ if ] https://php.net/manual/pt_BR/control-structures.if.php
 * [ elseif ] https://php.net/manual/pt_BR/control-structures.elseif.php
 * [ else ] https://php.net/manual/pt_BR/control-structures.else.php
 */

 $template = '<p>%s</p>';

fullStackPHPClassSession("if, elseif, else", __LINE__);

false;

if(false) {
    printf($template, 'Verdadeiro');
} else {
    printf($template, 'Falso');
}

if(true) {
    printf($template, 'Verdadeiro');
} else {
    printf($template, 'Falso');
}

$age = 55;

if($age > 18 && $age < 30) {
    printf($template, 'Você tem mais de 18 anos');
} else if($age >= 30) {
    printf($template, 'Você tem 30 anos ou mais');
} else {
    printf($template, 'Você tem 18 anos ou menos');
}


/*
 * [ isset ] https://php.net/manual/pt_BR/function.isset.php
 * [ empty] https://php.net/manual/pt_BR/function.empty.php
 */
fullStackPHPClassSession("isset, empty, !", __LINE__);

$arrayVazia = [];
$arrayCheia = [1, 2, 4];
$stringVazia = '';
$stringCheia = 'gabriel';

if(isset($arrayVazia['indice'])) {
    // isset testa se a variavel tiver definida retorna true
    printf($template, 'Definido');
} else {
    printf($template, 'Não definido');
}

$undefined = false;
// retorna truen se o argumento passado a ela estiver definido e com valor falsy
if(empty($stringCheia)) {
    printf($template, 'Não está definido ou tem o valor falsy');
}else if(!empty($stringCheia)) {
    printf($template, 'Definido e com valor trusty');
}else {
    printf($template, 'Não tem nem valor e nem foi definida');
}


/*
 * [ switch ] https://secure.php.net/manual/pt_BR/control-structures.switch.php
 */
fullStackPHPClassSession("switch", __LINE__);

$drink = 'vitamina';

switch($drink) {
    case 'agua':
        printf($template, 'Escolheu agua');
    break;
    case 'suco':
        printf($template, 'Escolheu suco');
    break;
    default :
        printf($template, 'Não escolheu nem agua nem suco');
}




