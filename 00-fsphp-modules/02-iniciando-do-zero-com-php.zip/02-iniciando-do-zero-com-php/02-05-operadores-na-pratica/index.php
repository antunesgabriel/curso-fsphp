<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
echo fullStackPHPClassName("02.05 - Operadores na prática");

/**
 * [ operadores ] https://php.net/manual/pt_BR/language.operators.php
 * [ atribuição ] https://php.net/manual/pt_BR/language.operators.assignment.php
 */
fullStackPHPClassSession("atribuição", __LINE__);

$value;
$atribuicoes = [
    '$value = 5' => ($value = 5),
    '$value += $value' => ($value += $value),
    '$value -= $value' => ($value -= 3),
    '$value *= $value' => ($value *= $value),
    '$value /= $value' => ($value /= 2),
    '$value %= $value' => ($value %= 7)
];
var_dump($atribuicoes);

/**
 * [ comparação ] https://php.net/manual/pt_BR/language.operators.comparison.php
 */
fullStackPHPClassSession("comparação", __LINE__);
$logicA = 7;
$logicB = '7';
$logicC = 5;
$logicD = 10;

$comparacao = [
    '$logicA == $logicB' => ($logicA == $logicB),
    '$logicA === $logicB' => ($logicA === $logicB), // compara também o tipo
    '$logicA > $logicA' => ($logicA > $logicD),
    '$logicA < $logicC' => ($logicC < $logicC),
    '$logicA >= logicA' => ($logicA >= $logicA),
    '$logicC <= logicA' => ($logicC <= $logicA),
    '$logicA != $logicB' => ($logicA != $logicB),
    '$logicA !== $logicB' => ($logicA !== $logicB)
];
var_dump($comparacao);

/**
 * [ lógicos ] https://php.net/manual/pt_BR/language.operators.logical.php
 */
fullStackPHPClassSession("lógicos", __LINE__);
// && , ||, !

$true = true;
$false = false;

$logic = [
    '$true && $false' => ($true && $false),
    '$true || $false' => ($true || $false),
    '!$false' => (!$false),
    '!$true' => (!$true)
];
var_dump($logic);


/**
 * [ aritiméticos ] https://php.net/manual/pt_BR/language.operators.arithmetic.php
 */
fullStackPHPClassSession("aritiméticos", __LINE__);
$value1 = 5;
$value2 = 10;
$value3 = 42;
$value4 = 27;

$aritimetic = [
    '$value1 + $value2' => ($value1 + $value2),
    '$value3 - $value1' => ($value3 - $value1),
    '$value4 / $value1' => ($value4 / $value1),
    '$value3 % $value1' => ($value3 % $value1)
];
var_dump($aritimetic);
