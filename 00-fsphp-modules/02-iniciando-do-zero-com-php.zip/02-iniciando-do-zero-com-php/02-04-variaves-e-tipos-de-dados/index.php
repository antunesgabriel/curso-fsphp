<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("02.04 - Variáveis e tipos de dados");

/**
 * [tipos de dados] https://php.net/manual/pt_BR/language.types.php
 * [ variáveis ] https://php.net/manual/pt_BR/language.variables.php
 */
fullStackPHPClassSession("variáveis", __LINE__);

$paragraph = "<p>%s</p>";

// definindo variavel simples
$name = 'Gabriel';
printf($paragraph, $name);

// definindo variavel variavel
$$name = 'é meu nome';
printf($paragraph, $Gabriel);

// fazendo referencia
//errado :
$numberA = 5;
$numberB = $numberA;

printf($paragraph, 'A: ' . $numberA);
printf($paragraph,'B: ' . $numberB);

$numberB = 10;

printf($paragraph, 'A: ' . $numberA);
printf($paragraph,'B: ' . $numberB); // valor referenciado não muda

// certo
$numberC = 18;
$numberD = &$numberC;

printf($paragraph, $numberC);
printf($paragraph, $numberD);

$numberD = 1;

printf($paragraph, $numberC);
printf($paragraph, $numberD); // ambos os valores mudam

$numberC = 5;

printf($paragraph, $numberC);
printf($paragraph, $numberD); // ambos os valores mudam

/**
 * [ tipo boleano ] true | false
 */
fullStackPHPClassSession("tipo boleano", __LINE__);
var_dump(true); // boolean true
var_dump(false); // boolean false

// equivalentes booleanos
$stringFalsy = '';
$null = null;
$intFalsy = 0;
$floatFalsy = 0.0;
$arrayFalsy = [];

echo '<h4>Equivalente booleano é:</h4>';

if($stringFalsy || $null || $intFalsy || $floatFalsy || $arrayFalsy) {
    var_dump(true);
}else {
    var_dump(false);
};

/**
 * [ tipo callback ] call | closure
 */
fullStackPHPClassSession("tipo callback", __LINE__);

// funções do tipo callback são funções que recebem e executam outras funções
$call = function($number) {
    echo $number;
};

call_user_func($call, 8); // callback

var_dump($call);


/**
 * [ outros tipos ] string | array | objeto | numérico | null
 */
fullStackPHPClassSession("outros tipos", __LINE__);

$string = 'This`s string';
$array = [1,2,3];
$object = new stdClass();
$number = 18;
$null = null;

var_dump([
    $string,
    $array,
    $object,
    $number,
    $null
]);
