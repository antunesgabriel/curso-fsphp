<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("02.06 - Arrays, vetores e pilhas");

/**
 * [ arrays ] https://php.net/manual/pt_BR/language.types.array.php
 */
fullStackPHPClassSession("index array", __LINE__);

$array1 = array(1, 2, 3, 4, 5);
var_dump($array1);

$array2 = [1, 2, 3, 4, 5];
var_dump($array2);

$array2[] = 6;
var_dump($array2);

/**
 * [ associative array ] "key" => "value"
 */
fullStackPHPClassSession("associative array", __LINE__);

$line = [
    'atacante' => 'Neymar',
    'meia' => 'Dudu',
    'volante' => 'Gerson',
    'lateral' => 'Rafinha',
    'zaga' => 'Dedé',
    'goleiro' => 'Santos'
];
var_dump($line);

/**
 * [ multidimensional array ] "key" => ["key" => "value"]
 */
fullStackPHPClassSession("multidimensional array", __LINE__);

$matriz = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
];
var_dump($matriz);

$camisaNumero = [
    'atacante' => 11,
    'meia' => 10,
    'volante' => 8,
    'lateral' => 6,
    'zaga' => 4,
    'goleiro' => 1
];

$associativeMatriz = [
    'jogadores' => $line,
    'numeroCamisa' => $camisaNumero
];
var_dump($associativeMatriz);


/**
 * [ array access ] foreach(array as item) || foreach(array as key => value)
 */
fullStackPHPClassSession("array access", __LINE__);

$template = "<p>%s - O camisa %s da seleção Brasileira é o %s.</p>";

printf($template, $array1[0], $associativeMatriz['numeroCamisa']['atacante'], $line['atacante']);