<?php

define('USER', 'Gabriel');

const USER2 = 'Antunes';

// const é mais recomendado para uso em classes;
// define é para outros fora de uma classe;