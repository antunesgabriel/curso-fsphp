<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("02.12 - Constantes e constantes mágicas");

/*
 * [ constantes ] https://php.net/manual/pt_BR/language.constants.php
 */
fullStackPHPClassSession("constantes", __LINE__);

require_once __DIR__ . '/constants.php';

echo '<span class="tag">' . USER . '</span>  ', '<span class="tag">' . USER2 . '</span>';
// constantes não podem ser fixada dentro de string como variaveis


/*
 * [ constantes mágicas ] https://php.net/manual/pt_BR/language.constants.predefined.php
 */
fullStackPHPClassSession("constantes mágicas", __LINE__);

echo '<p>' . __LINE__ . '</p>';
echo '<p>' . __DIR__ . '</p>';
// o php possui constantes ja prontas para uso;