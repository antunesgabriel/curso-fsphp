<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("02.08 - Estruturas de repetição");

/*
 * [ while ] https://php.net/manual/pt_BR/control-structures.while.php
 * [ do while ] https://php.net/manual/pt_BR/control-structures.do.while.php
 */
fullStackPHPClassSession("while, do while", __LINE__);

$countWhile = 0;
$arrayWhile = [];

while ($countWhile <= 10) {
    $arrayWhile[] = $countWhile;
    ++$countWhile;
}
var_dump($arrayWhile);

$countDoWhile = 20;
$arrayDoWhile = [];
do {
    $arrayDoWhile[] = $countDoWhile;
    --$countDoWhile;
} while($countDoWhile >= 10);
var_dump($arrayDoWhile);

/*
 * [ for ] https://php.net/manual/pt_BR/control-structures.for.php
 */
fullStackPHPClassSession("for", __LINE__);

for($count = 0; $count <= 10; $count++) {
    echo '<span class="tag">' . $count . '</span>';
}


/**
 * [ break ] https://php.net/manual/pt_BR/control-structures.break.php
 * [ continue ] https://php.net/manual/pt_BR/control-structures.continue.php
 */
fullStackPHPClassSession("break, continue", __LINE__);

echo '<h4>Salta todos números impares</h4>';
for($count = 0; $count <= 10; $count++) {
    if ($count % 2 === 1) {
        continue;
    }
    echo '<span class="tag">' . $count . '</span>';
}

echo '<h4>Quando chega ao primeiro numero par para</h4>';
for($count = 15; $count > 0; $count--) {
    if($count % 2 === 0) {
        break;
    }
    echo '<span class="tag">' . $count . '</span>';
}


/**
 * [ foreach ] https://php.net/manual/pt_BR/control-structures.foreach.php
 */
fullStackPHPClassSession("foreach", __LINE__);

$values = [
    'gabriel',
    'antunes',
    'dias',
    'teixeira',
    'programador'
];

echo '<h4>Values Only</h4>';
foreach($values as $value) {
    echo '<span class="tag">' . $value . '</span> <br />';
}

$keysAndValues = [
    'volante' => 'Gabriel',
    'meia' => 'Dudu',
    'lateral' => 'Daniel',
    'goleiro' => 'Zé'
];

echo '<h4>Values and Keys</h4>';
foreach($keysAndValues as $key => $value) {
    echo "
        <p>
            <strong>{$key}:</strong> {$value}
        </p>
    ";
}
