<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("02.09 - Closures e generators");

/*
 * [ closures ] https://php.net/manual/pt_BR/functions.anonymous.php
 */
fullStackPHPClassSession("closures", __LINE__);
// funções anônimas

$formatPrice = function ($price) {
    return number_format($price, 2, ',', '.');
};

echo '<span class="tag">R$' . $formatPrice(1554) . '</span>';
echo '<span class="tag">R$' . $formatPrice(50) . '</span>';

$car = [
    'totalPrice' => 0
];

$addItemToCar = function ($item, $price, $qtd) use (&$car) {
    $car[$item] = $price * $qtd;
    $car['totalPrice'] += $car[$item];
};

$addItemToCar('camisa', 45.89, 3);
$addItemToCar('bermuda', 50.00, 5);

var_dump($car);

/*
 * [ generators ] https://php.net/manual/pt_BR/language.generators.overview.php
 */
fullStackPHPClassSession("generators", __LINE__);

function renderData($days)
{
    for ($count = 0; $count < $days; $count++) {
        yield date('d/m/Y', strtotime("+{$count}days"));
    }
}

foreach (renderData(40) as $date) {
    echo '<span class="tag">' . $date . '</span>';
}