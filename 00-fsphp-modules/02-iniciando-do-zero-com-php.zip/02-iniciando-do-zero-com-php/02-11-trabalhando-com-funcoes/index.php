<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("02.11 - Trabalhando com funções");

/*
 * [ functions ] https://php.net/manual/pt_BR/language.functions.php
 */
fullStackPHPClassSession("functions", __LINE__);

require_once __DIR__ . '/funcoes.php';

var_dump(functionNames('Gabriel', 'Mila', 'Carregados'));

var_dump(optionalArgs('arg obrigatório'));
var_dump(optionalArgs('arg obrigatório', 'arg não obrigatório'));
var_dump(optionalArgs('arg obrigatório', 'arg não obrigatório', 'arg não obrigatório'));

/*
 * [ global access ] global $var
 */
fullStackPHPClassSession("global access", __LINE__);

$user = new StdClass(); // este objeto tem permissão pra ser acessado de dentro da functionde forma global
$user->name = 'Gabriel Antunes';
$user->email = 'gabrielantunescontato@gmail.com';
echo globalScope();

/*
 * [ static arguments ] static $var
 */
fullStackPHPClassSession("static arguments", __LINE__);

$product = new StdClass();

$product->price = 10.55;
$product->amount = 4;
echo staticArgument($product);

$product->price = 179;
$product->amount = 5;
echo staticArgument($product);

$product->price = 56.47;
$product->amount = 7;
echo staticArgument($product);

echo (56.47 * 7) + (10.55 * 4) + (179 * 5);

/*
 * [ dinamic arguments ] get_args | num_args
 */
fullStackPHPClassSession("dinamic arguments", __LINE__);

var_dump(dinamicArgs('gabriel', 'dias', 'teixeira', 'antunes'));