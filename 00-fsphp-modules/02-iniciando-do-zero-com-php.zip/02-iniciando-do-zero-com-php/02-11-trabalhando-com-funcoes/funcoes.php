<?php

function functionNames($name1, $name2, $name3)
{
    $names = [$name1, $name2, $name3];
    return $names;
}

function optionalArgs($arg1, $arg2 = false, $arg3 = null)
{
    return [$arg1, $arg2, $arg3];
}

function globalScope()
{
    global $user;
    return "<span class='tag'>{$user->name} - {$user->email}</span>";
}

function staticArgument($product)
{
    static $total = 0;
    $total += ($product->price * $product->amount);
    return '<p>R$' . number_format($total, 2, ',', '.') . '</p>';
}

function dinamicArgs()
{
    $args = func_get_args();
    $numArgs = func_num_args();

    return [
        'args' => $args,
        'numArgs' => $numArgs
    ];
}