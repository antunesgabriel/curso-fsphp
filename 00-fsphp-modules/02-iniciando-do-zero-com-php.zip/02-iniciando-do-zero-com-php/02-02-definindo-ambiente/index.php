<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("02-02-definindo-ambiente");

/*
 *
 */
fullStackPHPClassSession('Debug Section', __LINE__);

$test = [
    'nome' => 'gabriel'
];

var_dump($test);
