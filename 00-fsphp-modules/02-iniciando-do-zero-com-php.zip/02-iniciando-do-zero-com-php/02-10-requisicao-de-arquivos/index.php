<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("02.10 - Requisição de arquivos");

/*
 * [ include ] https://php.net/manual/pt_BR/function.include.php
 * [ include_once ] https://php.net/manual/pt_BR/function.include-once.php
 */
fullStackPHPClassSession("include, include_once", __LINE__);
// include inclui o arquivo, porem se ele não existir o
// o software não para
// usar para arquivos que o seu código "não precisa" para funcionar

$user = new StdClass();
$user->name = 'Gabriel';
$user->email = 'agentedacia@fakemail.com';
include __DIR__ . '/header.php';

$user->name = 'Ana paula';
$user->email = 'agentedacia2@fakemail.com';
include __DIR__ . '/header.php'; // sem once ele importa mais uma vez msm se ja estiver sido importado

$user->name = 'Não existe';
$user->email = 'naoexiste@email.com';

include_once __DIR__ . '/header.php'; // não ira mostrar pois o arquivo ja foi incluido acima
// include ou require _once só inclui se o arquivo ja não estiver sido incluido

// include_once __DIR__ . '/naoexiste.php';
// mesmo se o arquivo não existir o código continua
// echo "passou";

/*
 * [ require ] https://php.net/manual/pt_BR/function.require.php
 * [ require_once ] https://php.net/manual/pt_BR/function.require-once.php
 */
fullStackPHPClassSession("require, require_once", __LINE__);
// require inclui o arquivo, porem se não existir o software
// para e da erro (usar com arquivos que seu código nescessita para funciona)

// ambos usando once inclui o arquivo só se ele ja não estiver incluso

require_once __DIR__ . '/config.php';

echo '<span class="tag">' . DBNAME . '</span>';
// constantes não são inseridas em "{}" como as variaveis
// elas precisam ser concatenadas

// require_once __DIR__ . '/naoexiste.php';
// se o arquivo não existir o código para e da erro

// echo "passou";