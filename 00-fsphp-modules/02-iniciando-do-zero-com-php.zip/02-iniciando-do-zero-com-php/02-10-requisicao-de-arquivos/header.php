<style>
.header {
    background-color: #f2f2f2;
}
</style>
<header class="header">
    <h1><?= $user->name; ?></h1>
    <h2><a href="mailto:<?= $user->email; ?>">Me envie um email</a></h2>
</header>
