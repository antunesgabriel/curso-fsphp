<?php
define('DBNAME', 'stylus_dev');